
<?=include('include/header.php')?>
<?php $this->load->model('User_model'); ?>
<?=include('include/nav-bar.php')?>
		<!-- begin #content -->
		<div id="content" class="content">
			<!-- begin breadcrumb -->
			<ol class="breadcrumb pull-right">
				<li class="breadcrumb-item"><a href="javascript:;">Home</a> </li>
				<li class="breadcrumb-item"><a href="javascript:;">Dashboard</a></li>

			</ol>

			<!-- begin page-header -->
			<h1 class="page-header">Dashboard <small></small></h1>
			<!-- end page-header -->

			<!-- begin row -->
			<div class="row">
				<!-- begin col-3 -->
				<!-- <div class="col-lg-3 col-md-6">
					<div class="widget widget-stats bg-red">
						<div class="stats-icon"><i class="fa fa-desktop"></i></div>
						<div class="stats-info">
							<h4>BUY BTC</h4>
							<?php $buy=$this->User_model->get_Trans_Value(1)?>
							<p><?= number_format($buy,2)?></p>
						</div>

					</div>
				</div> -->
				<!-- end col-3 -->
				<!-- begin col-3 -->
				<div class="col-lg-3 col-md-6">
					<div class="widget widget-stats bg-orange">
						<div class="stats-icon"><i class="fa fa-link"></i></div>
						<div class="stats-info">
							<h4>Total Trade</h4>
							<?php $sell=$this->User_model->get_Trans_Value(2)?>
							<p><?= number_format($sell,2)?></p>
						</div>

					</div>
				</div>
				<!-- end col-3 -->
				<!-- begin col-3 -->
				<!-- <div class="col-lg-3 col-md-6">
					<div class="widget widget-stats bg-grey-darker">
						<div class="stats-icon"><i class="fa fa-users"></i></div>
						<div class="stats-info">
							<h4>BORROW BTC</h4>
							<?php $br=$this->User_model->get_Trans_Value(3)?>
							<p><?= number_format($br,2)?></p>
						</div>

					</div>
				</div> -->
				<!-- end col-3 -->
				<!-- begin col-3 -->
				<!-- <div class="col-lg-3 col-md-6">
					<div class="widget widget-stats bg-black-lighter">
						<div class="stats-icon"><i class="fa fa-clock"></i></div>
						<div class="stats-info">
							<h4>LENT BTC</h4>
							<?php $lent=$this->User_model->get_Trans_Value(4)?>
							<p><?= number_format($lent,2)?></p>
						</div>

					</div>
				</div> -->
				<!-- end col-3 -->
			</div>
			<!-- end row -->
			<!-- begin panel -->
			<div class="panel panel-inverse">
				<div class="panel-heading">
					<div class="panel-heading-btn">
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-redo"></i></a>
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger" data-click="panel-remove"><i class="fa fa-times"></i></a>
					</div>
					<h4 class="panel-title">Dashboard</h4>
				</div>
				<div class="panel-body">


				</div>
			</div>
			<!-- end panel -->
		</div>
		<!-- end #content -->


		<!-- begin scroll to top btn -->
		<a href="javascript:;" class="btn btn-icon btn-circle btn-success btn-scroll-to-top fade" data-click="scroll-top"><i class="fa fa-angle-up"></i></a>
		<!-- end scroll to top btn -->
	</div>
	<!-- end page container -->

	<?=include('include/footer.php')?>

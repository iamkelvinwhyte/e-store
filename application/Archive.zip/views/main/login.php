<?php include 'inc/header.php'; ?>
    <body class="auth-page sign-in">

        <div class='loader'>
            <div class='spinner-grow text-primary' role='status'>
                <span class='sr-only'>Loading...</span>
            </div>
        </div>
        <div class="connect-container align-content-stretch d-flex flex-wrap">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="auth-form">
                            <div class="row">

                                <div class="col">
                                    <div class="logo-box"><a href="#" class="logo-text">SIGNIN</a></div>
                                    <?=validation_errors('<div class="alert alert-danger">
                                    <center><strong>','</strong></center></div>'); ?>
                                    <?php
                                    if(isset($_SESSION['error'])){
                                      echo '<div class="alert alert-danger">
                                      <center><strong>'.$this->session->flashdata('error').'</strong></center></div>';
                                    }
                                    if(isset($_SESSION['success'])){
                                      echo '<div class="alert alert-success">
                                      <center><strong>'.$this->session->flashdata('success').'</strong></center></div>';
                                    }
                                    ?>
                                    <form method="post" action="<?=base_url()?>auth/activ_login_wallet">
                                        <div class="form-group">
                                            <input type="email"  name="email" class="form-control" id="email1" placeholder="Enter email" required>
                                            <input type="hidden"  name="ref" class="form-control" id="ref"  >
                                        </div>

                                        <div class="form-group">
                                            <input type="password"  name="password" class="form-control" id="exampleInputPassword1" placeholder="Password" required>
                                        </div>

                                        <button type="submit" class="btn btn-warning btn-block btn-submit">Sign In</button>
                                        <div class="auth-options">
                                            <div class="custom-control custom-checkbox form-group">
                                                <input type="checkbox" class="custom-control-input" id="exampleCheck1">
                                                <label class="custom-control-label" for="exampleCheck1">Sign me in</label>
                                            </div>
                                            <a href="<?=base_url()?>auth/password" class="forgot-link">Forget Password?</a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="auth-image"></div>
                    </div>
                </div>
            </div>
        </div>


<?php include 'inc/footer.php'; ?>

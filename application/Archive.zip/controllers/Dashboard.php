<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

public function __construct() { 
        parent::__construct();
        //load user model
        $this->load->model('Homepage_model');
        $this->load->model('Auth_model');
      

    }

public function index()
      {
      $userID_data=['personal_info_id'=>$this->session->userdata('personal_info_id') ,'loan_type'=>1];
      $userID_data2=['personal_info_id'=>$this->session->userdata('personal_info_id') ,'loan_type'=>0];
      $userID_data3=['personal_info_id'=>$this->session->userdata('personal_info_id')];
      $Msettle = $this->Homepage_model->DisplaySum_('loan',$userID_data,'loan_id');
      $Munsettle = $this->Homepage_model->DisplaySum_('loan',$userID_data2,'loan_id');
      $cob= $this->Homepage_model->DisplaySum_('contribution',$userID_data3,'contribution_id');
      $data['Msettle'] = $Msettle->amount;
      $data['Munsettle'] = $Munsettle->amount;
      $data['cob'] = $cob->amount;
      $this->load->view('app/dashboard',$data);
      }

}

?>
<?php include 'inc/header.php'; ?>
    <body>
        <div class='loader'>
            <div class='spinner-grow text-primary' role='status'>
                <span class='sr-only'>Loading...</span>
            </div>
        </div>
        <div class="connect-container align-content-stretch d-flex flex-wrap">
            <div class="page-container">
              <?php include 'inc/top_nav.php'; ?>
              <?php include 'inc/navbar.php'; ?>

                <div class="page-content">

                <?php if($this->session->userdata("active")==0){ ?>
                <div class="alert alert-danger">
                    <center><h3>Almost done...</h3><strong> We've sent an email to <u><?=$this->session->userdata("email")?></u>. Open it up to activate your account.</strong></center>
                </div>
              <?php }?>

                    <div class="page-info container">
                        <div class="row">
                            <div class="col">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#"><?=$this->config->item('site_name');?></a></li>
                                        <li class="breadcrumb-item active" aria-current="page">My Profile</li>
                                    </ol>
                                </nav>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                      <div class="col-lg-3"></div>
                            <div class="col-lg-6" >
                                <div class="card"  >
                                  <div class="card-header">

                                        <center><h3  href="#"><center> My Profile</h3></center>

                                  </div>
                                  <div class="card-body" >
                                    <?php
                                    if(isset($_SESSION['error'])){
                                      echo '<div class="alert alert-danger">
                                      <center><strong>'.$this->session->flashdata('error').'</strong></center></div>';
                                    }
                                    if(isset($_SESSION['success'])){
                                      echo '<div class="alert alert-success">
                                      <center><strong>'.$this->session->flashdata('success').'</strong></center></div>';
                                    }
                                    ?>
                                  <form method="post" action="<?=base_url()?>main/save_profile">
                                                 <div class="form-row">
                                                     <div class="form-group col-md-6">
                                                         <label for="inputEmail4">First Name</label>
                                                         <input type="text" class="form-control"name="f_name" value="<?=$this->session->userdata("f_name")?>" required>
                                                     </div>
                                                     <div class="form-group col-md-6">
                                                         <label for="inputPassword4">Last Name</label>
                                                         <input type="text" class="form-control" name="l_name" value="<?=$this->session->userdata("l_name")?>" required>
                                                     </div>
                                                 </div>
                                                 <div class="form-group">
                                                     <label for="inputAddress">Email</label>
                                                     <input type="email" class="form-control" id="inputAddress" readonly value="<?=$this->session->userdata("email")?>">
                                                 </div>
                                                 <div class="form-group">
                                                     <label for="inputAddress">Phone Number</label>
                                                     <input type="number" class="form-control" id="inputAddress" value="<?=$this->session->userdata("phone")?>" name="phone" required>
                                                 </div>
                                                 <br>
                                                  <br>
                                                 <div class="form-group">
                                                     <label for="inputAddress2"> Bitcoin Address </label>
                                                     <input type="text" class="form-control" id="inputAddress2" placeholder="Bitcoin Address" name="btc_address" value="<?=$this->session->userdata("btc_address")?>" required>
                                                 </div>

                                                 <div class="form-group">
                                                     <label for="inputAddress2"> Ethereum  Address </label>
                                                     <input type="text" class="form-control" id="inputAddress2" placeholder="Ethereum Address" name="eth_address" value="<?=$this->session->userdata("eth_address")?>" required>
                                                 </div>

                                                 <button type="submit" class="btn btn-warning">Save</button>
                                             </form>

                                </div>
                                </div>
                            </div>
                              <div class="col-lg-3"></div>

                        </div>





                </div>
                <div class="page-footer">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                              <span class="footer-text"><?=date("Y")?> © <?=$this->config->item('site_name');?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php include 'inc/footer.php'; ?>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

   
public function TranIn_($data){
$query=$this->db->insert('transaction', $data);
return $query;

}

public function Wallet_($data){
    $query=$this->db->insert('wallet', $data);
    return $query;
    
    }
 public function  DuplicateWallet_($data){
        $this->db->select('*');
        $this->db->from('wallet');
        $this->db->where($data);
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
        return true;
        } else {
        return false;
}
  }

  public function  DisplayWallet_($data){
    $this->db->select('*');
    $this->db->from('wallet');
    $this->db->where($data);
    $query = $this->db->get();
    return $query->result_array();

}
public function Displayrate_($data){
    $this->db->select('*');
    $this->db->from('rate');
    $this->db->where('acct_type',$data);
    $query = $this->db->get();
    return $query->result_array();
    
    }
    public function Displayrate_F($data){
        $this->db->select('*');
        $this->db->from('rate');
        $this->db->where($data);
        $query = $this->db->get();
        return $query->result_array();
        
        }
public function Displayrate_IN($data){
        $this->db->select('rate.amt,rate.rate_id,,rate.currency,currency_address.address');
        $this->db->from('rate');
        $this->db->where($data);
        $this->db->join('currency_address','currency_address.currency=rate.currency','INNER');
        $query = $this->db->get();
        return $query->result();
        
        }
        
public function Displaycur_AD($data){
            $this->db->select('*');
            $this->db->from('currency_address');
            $this->db->where('currency',$data);
            $query = $this->db->get();
            return $query->result();
            
    }
    ///ADMIN CURR
    public function AdminDisplaycur_AD(){
        $this->db->select('*');
        $this->db->from('currency_address');
        $query = $this->db->get();
        return $query->result_array();
        
}
   ///ADMIN INFO
   public function AdminDisplayINFO_AD(){
    $this->db->select('*');
    $this->db->from('personal_info');
    $query = $this->db->get();
    return $query->result_array();
    
}
    //Admin
    public function AdminDisplayrate_(){
        $this->db->select("*");
        $this->db->from('rate');
        $query = $this->db->get();
        return $query->result_array();
        
        }
 public function DisplayTran_AD($data){
                $this->db->select("*");
                $this->db->from('transaction');
                $this->db->where($data);
                $this->db->order_by('in_transaction_id', 'DESC');
                $query = $this->db->get();
                return $query->result();
                
    }
     public function DisplayTran_AD_all($data){
                $this->db->select("*");
                $this->db->from('transaction');
                $this->db->where($data);
                $this->db->order_by('in_transaction_id', 'DESC');
                $query = $this->db->get();
                return $query->result_array();
                
    }
    public function DisplayTran_LD($data){
        $this->db->select("*");
        $this->db->from('transaction');
        $this->db->where($data);
        $this->db->order_by('in_transaction_id', 'DESC');
        $query = $this->db->get();
        return $query->result();
        
}
    // Update User Details
function update_profile($id,$data){
    $this->db->where($id);
    $this->db->update('personal_info', $data);
    return TRUE;
    }

        // Update Transaction Details
function update_Trans($id,$data){
    $this->db->where($id);
    $this->db->update('transaction', $data);
    return TRUE;
    }


      // Update Rate Details
function update_Rate($id,$data){
    $this->db->where($id);
    $this->db->update('rate', $data);
    return TRUE;
    }

      // Update Wallet Details
      function update_WalletD($id,$data){
        $this->db->where($id);
        $this->db->update('currency_address', $data);
        return TRUE;
        }
    //password
public function Passwd_($query_array, $data){
        $this->db->update('personal_info', $data,$query_array);
        return TRUE;
        }

            //password
public function UserPasAdmin_($query_array, $data){
    $this->db->update('user', $data,$query_array);
    return TRUE;
    }

        ////Admin Display
        public function AdminDisplayTran_AD(){
            $this->db->select("*,(CASE trans_type
            WHEN  trans_type= '2'  THEN 'Deposit'
            WHEN  trans_type = '5'  THEN 'Cashout'
            ELSE 'Deposit' END) AS TransB
    
    ");
            $this->db->from('transaction');
            $this->db->order_by('in_transaction_id', 'DESC');
            $query = $this->db->get();
            return $query->result();
            
}

public function AdminDisplayTran_IN($id){
    $this->db->select("*,(CASE trans_type
    WHEN  trans_type=2 THEN 'Deposit'
    WHEN  trans_type =5  THEN 'Cashout'
    ELSE 'Cashout' END) AS TransB

");
    $this->db->from('transaction');
    $this->db->where($id);
    $this->db->join('personal_info','transaction.personal_info_id=personal_info.personal_info_id');
    $this->db->order_by('in_transaction_id', 'DESC');
    $query = $this->db->get();
    return $query->result();
    
}
//Trust Coin Wallet Sum
public function TWallet($id){
    $this->db->select("*");
    $this->db->from('transaction');
    $this->db->where($id);
    $query = $this->db->get();
     return $query->result_array();
    
}
//Trustcoin W
public function TwalletAmt()
	{
		$id = array
	(
   'personal_info_id' => $this->session->userdata('personal_info_id'),
   'trans_type' => 2,
   'aprove'	=> 1,
   'confirm_payement' => 1,
   'due <' => date("Y-m-d"),
   );
   $data=$this->User_model->TWallet($id);
  //$this->output->set_output(json_encode($data));
   $sum = 0; 
   $duration=11; 
    foreach($data as $datax){
    $amt= $datax["amount"];
    $bal= $datax["bal"];
    $sum+=$amt;
    }

    return $sum-$this->Redeposit();

    }
//Profit
public function ProfitAmt()
    {
        $id = array
    (
   'personal_info_id' => $this->session->userdata('personal_info_id'),
   'trans_type' => 2,
   'aprove' => 1,
   'confirm_payement' => 1,
   //'due <' => date("Y-m-d"),
   );
   $data=$this->User_model->TWallet($id);
  //$this->output->set_output(json_encode($data));
   $sum = 0; 
   $duration=11; 
    foreach($data as $datax){
    $bal= $datax["bal"];
    $sum+=$bal;
    }

    return $sum;

    }



    public function Redeposit()
    {
        $id = array
    (
   'personal_info_id' => $this->session->userdata('personal_info_id'),
   'trans_type' => 2,
    'lb' => 1,
   
   );
   $data=$this->User_model->TWallet($id);
  //$this->output->set_output(json_encode($data));
   $sum = 0;  
    foreach($data as $datax){
    $amt= $datax["amount"];
    $sum+=$amt;
    }
    return $sum;
    

    }
    
    //Trustcoin W
public function TwalletWitAmt()
	{
		$id = array
	(
   'personal_info_id' => $this->session->userdata('personal_info_id'),
   'trans_type' => 5,
   
   );
   $data=$this->User_model->TWallet($id);
  //$this->output->set_output(json_encode($data));
   $sum = 0;  
    foreach($data as $datax){
    $amt= $datax["amount"];
    $rate= $datax["rate"];
    $sum+=$amt;
    }
    return $sum;
	

    }
//Referral Calculator
public function TReferral($id){
    $this->db->select("*");
    $this->db->from('personal_info');
    $this->db->where($id);
    $this->db->join('transaction','personal_info.bit_vid=transaction.bit_vid');
    $query = $this->db->get();
     return $query->result_array();
    
}
///Referral Display
public function ReferralAmt()
	{
		$id = array
	(
   'ref' => $this->session->userdata('bit_vid'),
   'transaction.aprove'	=> 1,
   'transaction.confirm_payement' => 1,	
    'due <' => date('Y-m-d'),
   );
   $data=$this->User_model->TReferral($id);
  //$this->output->set_output(json_encode($data));
   $sum = 0;  
    foreach($data as $datax){
    $amt= $datax["amount"];
    $rate= $datax["rate"];
    $sum+=$amt;
    }
    return $sum*0.05 ;
	

    }
//Transaction Record
public function TRecord($id){
    $this->db->select("*");
    $this->db->from('transaction');
    $this->db->where('trans_type',$id);
    $this->db->order_by('in_transaction_id', 'DESC');
    $query = $this->db->get();
     return $query->result_array();
    
}
 
public function  get_Trans_Value($id){
    $data=$this->User_model->TRecord($id);
    $sum = 0;  
    foreach($data as $datax){
    $amt= $datax["amount"];
    $rate= $datax["rate"];
    $sum+=$amt*$rate;
    }
    return $sum ;
 }
//Remove Trans
function Del_Tans_($id){
    $this->db->where('in_transaction_id', $id);
    $a=$this->db->delete('transaction');
    if(isset($a)){return TRUE;}else{return FALSE;}
}

//Remove User
function Del_user_($id){
    $this->db->where('personal_info_id', $id);
    $a=$this->db->delete('personal_info');
    if(isset($a)){return TRUE;}else{return FALSE;}
}

function GetcurrencyUpdate($d,$b){
    $dat=array(
        'rate.currency' => $d,
        'rate.acct_type' => $b,
    );
    
    $data = $this->User_model->Displayrate_F($dat);
    foreach($data as $datax){
        $amt= $datax["amt"];
    
     
        }
        return $amt ;
    }


}
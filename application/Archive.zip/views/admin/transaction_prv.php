
<?=include('include/header.php')?>

<?=include('include/nav-bar.php')?>
		<!-- begin #content -->
		<div id="content" class="content">
			<!-- begin breadcrumb -->
			<ol class="breadcrumb pull-right">
				<li class="breadcrumb-item"><a href="javascript:;">Home</a></li>
				<li class="breadcrumb-item"><a href="javascript:;">Dashboard</a></li>

			</ol>

			<!-- begin page-header -->
			<h1 class="page-header">Dashboard <small></small></h1>
			<!-- end page-header -->
			<?php
			foreach ($trans as $key ) {
			  // code...
			}
			 ?>
			<!-- begin row -->
			<div class="row">
                <!-- begin col-3 -->

                </div>
			<!-- begin panel -->
			<div class="panel panel-inverse">
				<div class="panel-heading">
					<div class="panel-heading-btn">
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-redo"></i></a>
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger" data-click="panel-remove"><i class="fa fa-times"></i></a>
					</div>
					<h4 class="panel-title">Dashboard</h4>
				</div>
				<div class="panel-body" ng-app="myStock" ng-controller="StockCtrl" ng-init="show_data()" >

                <div class="col-12 table-responsive">
                     <!-- title row -->
      <div class="row">

      </div>
      <!-- /.row -->

			<div class="row" >
				<div class="col-lg-1"></div>
							<div class="col-lg-10" >
									<div class="card"  >
										<div class="card-header bg-success" ng-init="trans_type=<?=$key["trans_type"]?>">

							<center><h3 class="text-white" href="#"><center> Transaction Details </h3></center>


										</div>
										<div  class="card-body" ng-init="amount=<?=$this->session->userdata("amount")?>">
											<table class="table table-striped">

													<tbody>
														<tr>
															<th scope="row">Full Name</th>
															<td><?=$key["f_name"]?> <?=$key["l_name"]?> </td>
														</tr>

														<?php if($key["address"]==1){ ?>
														<tr>
															<th scope="row">Btc Address</th>
															<td><?=$key["btc_address"]?> </td>

														</tr>
													<?php  }?>

													<?php if($key["address"]==2){ ?>
													<tr>
														<th scope="row">Ethereum Address</th>
														<td><?=$key["eth_address"]?> </td>

													</tr>
												<?php  }?>

														<tr>
															<th scope="row">Amount</th>
																<td>$<?=number_format($key["amount"],2)?> </td>

														</tr>
														<tr>
															<th scope="row">Date</th>
															<td><?=$key["date"]?> </td>

														</tr>

														<tr ng-init="trans_type =<?=$key["trans_type"]?>">
															<th scope="row">Type</th>
															<td>
															<span  class="badge badge-success " ng-show="trans_type==1">+invest</span>
															 <span class="badge badge-primary" ng-show="trans_type==2">+reinvest</span>
													 <span class="badge badge-danger" ng-show="trans_type==3">-withdrawl</span>
															</td>

														</tr >

														<tr ng-init="aprove =<?=$key["aprove"]?>">
															<th scope="row">Status</th>
															<td><span class="badge badge-success" ng-show="aprove==1">active</span>
																<span class="badge badge-warning" ng-show="aprove==0">not active</span>

															</td>

														</tr>

													</tbody>
									</table>
								<?php if ($key["pay_file"]): ?>
									<img src="<?=base_url()?>uploads/<?=$key["pay_file"]?>" width="100%" height="600px">
								<?php endif; ?>

									</div>
									</div>
							</div>
								<div class="col-lg-1"></div>

					</div>
            </div>

			<!-- end panel -->
		</div>
		<!-- end #content -->


		<!-- begin scroll to top btn -->
		<a href="javascript:;" class="btn btn-icon btn-circle btn-success btn-scroll-to-top fade" data-click="scroll-top"><i class="fa fa-angle-up"></i></a>
		<!-- end scroll to top btn -->
	</div>
	<!-- end page container -->
    <script>

	var Stock = angular.module('myStock', ['angularUtils.directives.dirPagination']);
	////// STOCK QUERY DETAILS///////////
Stock.controller("StockCtrl", function($scope, $http) {
	 $scope.show_data = function() {
$http.get("<?=base_url()?>Bs/get_TranscAdmin")
            .then(function (response) {
               $scope.myUserData = response.data; //data call
            });
	 }
   //Upadte Database
    $scope.update_data = function(in_transaction_id) {
       if (confirm("Are you sure you want to Confirm Your Payment?")) {
            $http.post("<?=base_url()?>User/UpdateTrans_T", {
                    'in_transaction_id': in_transaction_id
                })
                 .then(function (response) {
                    alert(response.data);
                    $scope.show_data();
                });
        } else {
            return false;
        }

    }
	//alert Database
    $scope.delete_data = function(user_id) {
        if (confirm("Are you sure you want to Delete User?")) {
              $http.post("<?=base_url()?>Dashboard/Remove_stock", {
                    'user_id': user_id
                })
                .then(function (response) {
                    alert(response.data);
                    $scope.show_data();
                });
        } else {
            return false;
        }
    }

});

	</script>
	<?=include('include/footer.php')?>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Homepage_model extends CI_Model {

public function insertData_($db,$data){
$query=$this->db->insert($db, $data);
return $query;

}


//Select and Reg
public function mySelectIn($db,$data,$data2){
$this->db->select('*');
$this->db->from($db);
$this->db->where($data2);
$query_ =$this->db->get();
if ($query_->num_rows() == 1) {
return false;
} else {
$query=$this->db->insert($db, $data);
return $query;
}
}




//Login
public function Login_($db,$data){
$this->db->select('*');
$this->db->from($db);
$this->db->where($data);
$this->db->limit(1);
$query = $this->db->get();
if ($query->num_rows() == 1) {
return $query->result();
} else {
return false;
}


}

//Display Day All
public function DisplayAll_chart($db,$data,$order_id,$days){
 $pmy = $days;
$this->db->select('DATE_FORMAT(date_log, "%b %d") AS date ,COUNT(status) AS status, SUM(amount) AS amount');
$this->db->from($db);
$this->db->where($data);
//$this->db->where('DAY(date_log)',$pmy);
$this->db->where('date_log BETWEEN DATE_SUB(NOW(), INTERVAL '.$pmy.' DAY) AND NOW()');
$this->db->order_by($order_id, "Asc");
 $this->db->group_by('DAY(date_log)');
$query=$this->db->get();
return $query->result_array();
}

//Display  Month All
public function MonthDisplayAll_($db,$data,$order_id){
$this->db->select('DATE_FORMAT(date_log, "%M") AS date ,COUNT(status) AS status , SUM(amount) AS amount');
$this->db->from($db);
$this->db->where($data);
$this->db->order_by($order_id, "Asc");
$this->db->group_by('MONTH(date_log)');
$query=$this->db->get();

return $query->result_array();
}

//Number
public function DisplayNum_($db,$data,$order_id){
$this->db->select("*");
$this->db->from($db);
$this->db->where($data);
$this->db->order_by($order_id, "desc");
$query=$this->db->get();
return $query->num_rows();
}

public function DisplaySum_($db,$data,$order_id){
$this->db->select("SUM(amount) AS amount,SUM(bal) AS bal");
$this->db->from($db);
$this->db->where($data);
$this->db->order_by($order_id, "desc");
$query=$this->db->get();
return $query->row();
}



//Display JOIN
public function Display_Group($db1,$data,$order_id,$group_id){
$this->db->select("*");
$this->db->from($db1);
$this->db->where($data);
$this->db->group_by($group_id);
$this->db->order_by($order_id, "desc");
$query=$this->db->get();
return $query->result_array();
}

//Display All
public function DisplayAll_($db,$data,$order_id){
$this->db->select("*");
$this->db->from($db);
$this->db->where($data);
$this->db->order_by($order_id, "desc");
$query=$this->db->get();
return $query->result_array();
}

//Event Display All
public function Display_Defind($db,$data,$order_id){
$this->db->select("*");
$this->db->from($db);
$this->db->where($data);
$this->db->order_by($order_id, "desc");
$query=$this->db->get();
return $query;
}

//Display All
public function DisplayAl1_($db,$data,$order_id){
$this->db->select("*");
$this->db->from($db);
$this->db->where($data);
$this->db->limit(1);
$this->db->order_by($order_id, "desc");
$query=$this->db->get();
return $query->result_array();
}

//Display All
public function DisplayAl_Were($db,$data,$order_id){
$this->db->select("*");
$this->db->from($db);
$this->db->where_in($data);
$this->db->order_by($order_id, "desc");
$query=$this->db->get();
return $query->result_array();
}

// Update Date
function update_Data($id,$data,$db){
$this->db->where($id);
$this->db->update($db, $data);
return TRUE;
}

//Remove Media
function Del_Data_($db,$id){
$this->db->where( $id);
$a=$this->db->delete($db);
if(isset($a)){return TRUE;}else{return FALSE;}

}





//Display JOIN
public function DisplayJoin_($db1,$db2,$data,$id,$action,$join_type){
$this->db->select("*");
$this->db->from($db1);
$this->db->where($data);
$this->db->order_by($id, "desc");
$this->db->join($db2, $action,$join_type);
$query=$this->db->get();
return $query->result_array();

}
//Display JOIN
public function Display2Join_($db1,$db2,$db3,$data,$id,$action,$action3,$join_type,$join_type3){
$this->db->select("*");
$this->db->from($db1);
$this->db->where($data);
$this->db->order_by($id, "desc");
$this->db->join($db2, $action,$join_type);
$this->db->join($db3, $action3,$join_type3);
$query=$this->db->get();
return $query->result_array();

}
//Display JOIN3
public function MutiDisplayJoin_($db1,$db2,$db3,$db4,$data,$id,$action,$action3,$action4,$join_type,$join_type3,$join_type4){
$this->db->select("*");
$this->db->from($db1);
$this->db->where($data);
$this->db->order_by($id, "desc");
$this->db->join($db2, $action,$join_type);
$this->db->join($db3, $action3,$join_type3);
$this->db->join($db4, $action4,$join_type4);
$query=$this->db->get();
return $query->result_array();

}

//ACCOUNT BALANCE

public function AccountBal($trans_type)
{
  $data=$this->DisplaySum_("transaction",['aprove'=>1,"trans_type"=>$trans_type,"personal_info_id"=>$this->session->userdata("personal_info_id")],"in_transaction_id");
  if(!$data->amount){return 0; }
  return $data->amount;
}

public function AccountProfit()
{
  $data=$this->DisplaySum_("transaction",['aprove'=>1,"personal_info_id"=>$this->session->userdata("personal_info_id")],"in_transaction_id");
    if(!$data->bal){return 0; }
  return $data->bal;
}

public function AccountReDepositProfit()
{
  $data=$this->DisplaySum_("transaction",['aprove'=>1,"trans_type"=>2,"tran_in_type"=>2,"personal_info_id"=>$this->session->userdata("personal_info_id")],"in_transaction_id");
    if(!$data->bal){return 0; }
  return $data->bal;
}

public function walletBal()
{
//debit
$withdrawal=$this->AccountBal(3);
$re_deposit=$this->AccountBal(2);
//credit
$balance=$this->AccountProfit();
$referral=$this->ReferralBal();


return ($balance+$referral-$withdrawal-$re_deposit);
}


public function ProfitBal()
{
//credit
$profit=$this->AccountProfit();
return $profit;
}

public function TotalInvest()
{
//credit
$deposit=$this->AccountBal(1);
$re_deposit=$this->AccountBal(2);
return $deposit+$re_deposit;
}




public function ReferralBal()
{
  $data=$this->DisplaySum_("transaction",['aprove'=>1,"trans_type"=>1,"ref"=>$this->session->userdata("personal_info_id")],"in_transaction_id");
  if(!$data->amount){return 0; }
  return $data->amount * $this->config->item('referral_rate')/100;
}

public function ProfitBalOnly()
{
  return $this->ProfitBal()-$this->TotalInvest();
}

}


?>

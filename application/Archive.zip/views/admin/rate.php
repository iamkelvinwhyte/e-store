
<?=include('include/header.php')?>	

<?=include('include/nav-bar.php')?>		
		<!-- begin #content -->
		<div id="content" class="content">
			<!-- begin breadcrumb -->
			<ol class="breadcrumb pull-right">
				<li class="breadcrumb-item"><a href="javascript:;">Home</a></li>
				<li class="breadcrumb-item"><a href="javascript:;">Dashboard</a></li>
				
			</ol>
		
			<!-- begin page-header -->
			<h1 class="page-header">Dashboard <small></small></h1>
			<!-- end page-header -->
			
			<!-- begin row -->
			<div class="row">
                <!-- begin col-3 -->
             
                </div>
			<!-- begin panel -->
			<div class="panel panel-inverse">
				<div class="panel-heading">
					<div class="panel-heading-btn">
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-redo"></i></a>
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger" data-click="panel-remove"><i class="fa fa-times"></i></a>
					</div>
					<h4 class="panel-title">Rate</h4>
				</div>
				<div class="panel-body" ng-app="myStock" ng-controller="StockCtrl" ng-init="show_data()">
                <div class="table-responsive">
				<?php
				 if(isset($_SESSION['error'])){
				echo '<center><p style="color:#FF0000;font-size:12px"> <strong>'.$this->session->flashdata('error').'</p></center>'; 
                 }if(isset($_SESSION['success'])){
                    echo '<center><p style="color:#41BC21;font-size:12px"> <strong>'.$this->session->flashdata('success').'</p></center>'; 
                     }
                     
                                ?> 
						<table class="table table-bordered no-margin ">
						  <thead>					
							<tr>
							  <th><span style="">Rate ID</span></th>
							  <th><span style="">Currency</span></th>
                              <!--<th><span style="">Transaction Type</span></th>-->
                              <th><span style="">Rate</span></th>
                              <th><span style="">date</span></th>
                              <th><span style="">Action</span></th>
							</tr>
						  </thead>
						  <tbody dir-paginate="x in myUserData|orderBy:sortKey:reverse|filter:userSearch|itemsPerPage:10">
							<tr>
							  <td>
								<a href="" class="text-red hover-warning">
								  {{x.rate_id}}
								</a>
								
							  </td>
                              <td>{{x.currency}}</td>
                              <!--<td>{{x.TransB}}</td>-->
							  <td>
								<time class="timeago" >{{x.amt | currency  : ""}}</time>
                              </td>
                              <td>
								<time class="timeago" >{{x.date}}</time>
							  </td>
							  <td><a href="<?=base_url()?>Admin/edit_rate/{{x.rate_id}}/{{x.TransB}}"><span class="btn btn-xs btn-warning"  >Edit</span></a>
							 
                            </td>
							</tr>
							
						  </tbody>
                        </table>
                        <!--Pagination -->
				<dir-pagination-controls
					max-size="10"
					direction-links="true"
					boundary-links="true" >
				</dir-pagination-controls>
				<!--Pagination -->
					</div>
					
				</div>
            </div>
            
			<!-- end panel -->
		</div>
		<!-- end #content -->

		
		<!-- begin scroll to top btn -->
		<a href="javascript:;" class="btn btn-icon btn-circle btn-success btn-scroll-to-top fade" data-click="scroll-top"><i class="fa fa-angle-up"></i></a>
		<!-- end scroll to top btn -->
	</div>
	<!-- end page container -->
    <script>
	
	var Stock = angular.module('myStock', ['angularUtils.directives.dirPagination']);
	////// STOCK QUERY DETAILS///////////
Stock.controller("StockCtrl", function($scope, $http) {
	 $scope.show_data = function() {
$http.get("<?=base_url()?>Admin/get_RateAdmin")
            .then(function (response) {
               $scope.myUserData = response.data; //data call
            });
	 }		
   //Upadte Database
    $scope.update_data = function(in_transaction_id) {
       if (confirm("Are you sure you want to Confirm This Payment?")) {
            $http.post("<?=base_url()?>Admin/AdminUpdateTrans_T", {
                    'in_transaction_id': in_transaction_id
                })
                 .then(function (response) {
                    alert(response.data);
                    $scope.show_data();
                });
        } else {
            return false;
        }
	  
    }
	//alert Database
    $scope.delete_data = function(in_transaction_id) {
        if (confirm("Are you sure you want to Delete Transaction?")) {
              $http.post("<?=base_url()?>Admin/Remove_transaction", {
				'in_transaction_id': in_transaction_id
                })
                .then(function (response) {
                    alert(response.data);
                    $scope.show_data();
                });
        } else {
            return false;
        }
    }
	
});

	</script>
	<?=include('include/footer.php')?>
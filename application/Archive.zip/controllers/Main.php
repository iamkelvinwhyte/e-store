<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {

public function __construct() {
        parent::__construct();
        //load user model
        $this->load->model('Check_user');
        $this->Check_user->_is_logged_in();//CHECK SESSION LOGIN
        $this->load->model('Homepage_model');
        $this->load->model('Auth_model');

    }

public function test()
{
  $this->load->view('main/email.php');
}

public function index()
{
  $this->load->view('main/index.php');
}

public function plan()
{
  $this->load->view('main/plan.php');
}

public function success()
{
  $this->load->view('main/success.php');
}

public function my_plan()
{
  $this->load->view('main/my_plan.php');
}

public function profile()
{
  $this->load->view('main/profile.php');
}

public function withdrawal()
{
  $this->load->view('main/withdrawal.php');
}

public function referral()
{
  $this->load->view('main/referral.php');
}


//getMyPlan
public function getMyPlan(){
    $action="transaction.plan=rate.rate_id";
    $data = $this->Homepage_model->DisplayJoin_("transaction","rate",["personal_info_id"=>$this->session->userdata("personal_info_id"),"trans_type"=>1],"in_transaction_id",$action,"left");
    $this->output->set_output(json_encode($data));
}

//getPlan
public function getPlan(){
    $data = $this->Homepage_model->DisplayAll_('rate',[],'rate_id');
    $this->output->set_output(json_encode($data));
}

//getTransaction
public function getTransaction(){
    $data = $this->Homepage_model->DisplayAll_('transaction',["personal_info_id"=>$this->session->userdata("personal_info_id")],'in_transaction_id');
    $this->output->set_output(json_encode($data));
}

//imagesetinterpolation
public function invest_calculate($value='')
{
    $package = $this->Homepage_model->Display_Defind('rate',["rate_id"=>$value],'rate_id');
    if(!$package->row()){  redirect('main/plan', 'refresh');}
    $data["package"]=$package->row();
    $this->load->view('main/plan_cal.php',$data);
}


public function confirm_trade()
{
  $pay_type=$this->input->post('pay_type');
  if($pay_type){
    $trans_type=2;
    $aprove=1;
    $wallet_bal=$this->Homepage_model->walletBal();
    if($wallet_bal < $this->input->post('amount') )
    {
      $this->session->set_flashdata('error', 'Insufficient funds, please try again ');
        redirect('main/invest_calculate/'.$this->input->post('rate_id'), 'refresh');
    }
  }else{
  $trans_type=1;
  $aprove=0;
  }
  $ref=$this->session->userdata("ref");
  $amount=$this->input->post('amount');
  $data = [
    'amount' => $this->input->post('amount'),
    'bal' => $this->input->post('amount'),
    'plan' => $this->input->post('rate_id'),
    'invoice' =>   $code=$this->Auth_model->random_code(10),
    'rate' => $this->input->post('percent'),
    'duration' => $this->input->post('days'),
    'personal_info_id'=>$this->session->userdata("personal_info_id"),
    'trans_type'=>$trans_type,
    'tran_in_type'=>$trans_type,
    'aprove'=>$aprove,
    'ref'=> $ref?$ref:0,
];
$this->session->set_userdata($data);
$this->session->set_userdata(['payment_type' => $this->input->post('payment_type')]);
  $this->Homepage_model->insertData_("transaction",$data);

  $subject="Deposit Notification: Arcadia invest";
  $htmlContent=$this->DepositlMessage($amount);
  $this->send_email($this->config->item('notify_email'),$htmlContent,$subject);

    redirect('main/success', 'refresh');
}


public function save_profile()
{
  $data = [
    'f_name' => $this->input->post('f_name'),
    'l_name' => $this->input->post('l_name'),
    'phone' => $this->input->post('phone'),
    'btc_address' =>  $this->input->post('btc_address'),
    'eth_address' =>  $this->input->post('eth_address'),
];
$this->session->set_userdata($data);

$personal_info_id=$this->session->userdata("personal_info_id");
$this->Homepage_model->update_Data(["personal_info_id"=>$personal_info_id],$data,"personal_info");

$this->session->set_flashdata('success', 'Your profile has been successfully updated ');
redirect('main/profile', 'refresh');
}


public function make_withdrawl()
{
  $amount=$this->input->post('amount');
  $email=$this->session->userdata('email');
  $data = [
    'amount' => $this->input->post('amount'),
    'address'=>$this->input->post('payment_type'),
    'invoice' =>   $code=$this->Auth_model->random_code(10),
    'personal_info_id'=>$this->session->userdata("personal_info_id"),
    'trans_type'=>3,
    'aprove'=>1,
];

$wallet_bal=$this->Homepage_model->walletBal();
if($wallet_bal < $this->input->post('amount') )
{
  $this->session->set_flashdata('error', 'Insufficient funds, please try again ');
    redirect('main/withdrawal/', 'refresh');
}


$this->Homepage_model->insertData_("transaction",$data);
$this->session->set_flashdata('success', 'Your withdrawl was succesful , it take 10-15mins for your withdrawl to be confirmed');
//email notification for withdrawl

$subject="Withdrawal Request: Arcadia invest";
$htmlContent=$this->withdrawalMessage($amount);
$this->send_email($email,$htmlContent,$subject);
$this->send_email($this->config->item('notify_email'),$htmlContent,$subject);
redirect('main/withdrawal', 'refresh');
}


//getMyPlan
public function getReferral(){
    $data = $this->Homepage_model->DisplayAll_('personal_info',["ref"=>$this->session->userdata("personal_info_id")],'personal_info_id');
    $this->output->set_output(json_encode($data));

}



//ADMIN FUNCTION
public function users_admin()
{
  $this->load->view('main/admin_user.php');
}

public function admin_trans_all()
{
  $this->load->view('main/admin_trans.php');
}

public function user_all_email()
{
  $all_email = $this->Homepage_model->DisplayAll_('personal_info',[],'personal_info_id');
  $data["email"]=$all_email;
  $this->load->view('main/admin_email.php',$data);
}

public function getUser(){
    $data = $this->Homepage_model->DisplayAll_('personal_info',[],'personal_info_id');
    $this->output->set_output(json_encode($data));

}

public function UserAction()
{
  $data  = json_decode(file_get_contents("php://input"));
  	$personal_info_id= $data->personal_info_id;
    $type= $data->type;
    if($type==1){
  echo $this->Homepage_model->Del_Data_("personal_info",['personal_info_id'=>$personal_info_id]);
}else{
   echo $this->Homepage_model->update_Data(['personal_info_id'=>$personal_info_id],["active"=>0],"personal_info");
 }
}


public function getAllTransaction(){
  $action="transaction.plan=rate.rate_id";
  $action2="transaction.personal_info_id=personal_info.personal_info_id";
    $data = $this->Homepage_model->Display2Join_("transaction","rate","personal_info",[],"in_transaction_id",$action,$action2,"left","left");
    $this->output->set_output(json_encode($data));

}

public function TransactionAction()
{
  $data  = json_decode(file_get_contents("php://input"));
  	$in_transaction_id= $data->in_transaction_id;
    $type= $data->type;
    $duration= $data->duration;
    if($type==1){
  echo $this->Homepage_model->Del_Data_("transaction",['in_transaction_id'=>$in_transaction_id]);
}else{
   $dd="+".$duration."days";
  $data_arr=[  'aprove' => 1,'due'  => date('Y-m-d', strtotime($dd)),'confirm_payement'=>1];
   echo $this->Homepage_model->update_Data(['in_transaction_id'=>$in_transaction_id],$data_arr,"transaction");
 }
}

public function trans_details($in_transaction_id='')
{
  $action="transaction.plan=rate.rate_id";
  $action2="transaction.personal_info_id=personal_info.personal_info_id";
    $dataGet = $this->Homepage_model->Display2Join_("transaction","rate","personal_info",["in_transaction_id"=>$in_transaction_id],"in_transaction_id",$action,$action2,"left","left");
    $data["trans"]=$dataGet;
$this->load->view('main/admin_trans_details.php',$data);

}

public function paymentUpload()
{
  /* Getting file name */
  $image ="user.png";
  if (isset($_FILES['file']['name'])) {
    $filename = $_FILES['file']['name'];
    /* Location */
    $location = 'uploads/';

    $path = pathinfo($filename,PATHINFO_EXTENSION);
    $image = time().'.'.$path;

    /* Upload file */
    move_uploaded_file($_FILES['file']['tmp_name'],$location.$image);
  }

  $id =['personal_info_id' => $this->session->userdata('personal_info_id'),'invoice' => $this->session->userdata('invoice')];
  $data_arr=["pay_file"=>$image];
  $set_=$this->Homepage_model->update_Data($id,$data_arr,"transaction");


  if($set_){echo true;}else{echo false; }

}


  public function send_email($email,$htmlContent,$subject)
  {
      $from_email = $this->config->item('email');
      $to_email = $email;
      //Load email library
      $this->load->library('email');
      $config['mailtype'] = 'html';
       $this->email->initialize($config);
       $this->email->to($to_email);
      $this->email->from($from_email, 'Arcadia Invest ');
       $this->email->subject($subject);
      $this->email->message($htmlContent);

      //Send mail
      $this->email->send();

     }


public function withdrawalMessage($amount=0)
{
return '<div style="background-color:#F9F9F9">
<h1>Welcome to <span style="color:#FF8C00">Arcadia invest withdrawal </span></h1>

<p>
Withdrawal Request .<hr> You have requested to withdraw  $'.$amount.'  from your account
</p>

<br>
If you have any questions please feel free to reach out to us using the information on our contact page.
<br>
<i>Sincerely,
The Arcadia Team
</i>
</p>
</div>';
}

public function DepositlMessage($amount=0)
{
return '<div style="background-color:#F9F9F9">
<h1>Welcome to <span style="color:#FF8C00">Arcadia Invest Deposit </span></h1>

<p>
Withdrawal Request .<hr> You have made a depositof   $'.$amount.'  from your account
</p>

<br>
If you have any questions please feel free to reach out to us using the information on our contact page.
<br>
<i>Sincerely,
The Arcadia Team
</i>
</p>
</div>';
}





}

?>

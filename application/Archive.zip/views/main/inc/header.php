<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Arcadia invest is one of the world’s leading private multi asset alternative investment firms with approximately $105 billion in assets under management that create lasting impacts for our investors, teams, business and the communities in which we live">
        <meta name="keywords" content="Arcadia">
        <meta name="author" content="Arcadia">
        <!-- The above 6 meta tags *must* come first in the head; any other head content must come *after* these tags -->

        <!-- Title -->
        <title>Arcadia - Arcadia invest is one of the world’s leading private multi asset alternative investment firms</title>

        <!-- Styles -->
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,900&amp;display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700&amp;display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp" rel="stylesheet">
        <link href="<?=base_url()?>assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?=base_url()?>assets/plugins/font-awesome/css/all.min.css" rel="stylesheet">


        <!-- Theme Styles -->
        <link href="<?=base_url()?>assets/css/connect.min.css" rel="stylesheet">
        <link href="<?=base_url()?>assets/css/admin2.css" rel="stylesheet">
        <link href="<?=base_url()?>assets/css/dark_theme.css" rel="stylesheet">
        <link href="<?=base_url()?>assets/css/custom.css" rel="stylesheet">

        <!--AgularJS-->
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular.min.js"></script>
     <script src="<?= base_url() ?>assets/js/angularjs/angularJs.js"></script>
     <script src="<?= base_url() ?>assets/js/angularjs/dirPagination.js"></script>

     <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


     <style type="text/css">
     [ng\:cloak], [ng-cloak], [data-ng-cloak], [x-ng-cloak], .ng-cloak, .x-ng-cloak {
       display: none !important;
     }
     </style>

    </head>

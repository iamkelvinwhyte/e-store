<div class="horizontal-bar" >
    <div class="logo-box"><a href="#" class="logo-text"><?=$this->config->item('site_name');?></a></div>
    <a href="#" class="hide-horizontal-bar"><i class="material-icons">close</i></a>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="horizontal-bar-menu">
                    <ul>
                      <li><a href="<?=base_url()?>main" class="active">OVERVIEW</a></li>
                      <li><a href="<?=base_url()?>main/my_plan">MY PLAN</a></li>
                      <li><a href="<?=base_url()?>main/plan">INVEST</a></li>
                      <li><a href="<?=base_url()?>main/profile">PROFILE</a></li>
                      <li><a href="<?=base_url()?>main/referral">REFERRAL</a></li>
                      <li><a href="<?=base_url()?>main/withdrawal">WITHDRAWAL</a></li>
                      <li><a href="<?=base_url()?>main">SUPPORTS</a></li>
                    <?php if($this->session->userdata("account_type")=="A1"){ ?>
                      <li><a href="#">ADMIN<i class="material-icons">keyboard_arrow_down</i></a>
                        <ul>
                          <li>
                            <a href="<?=base_url()?>main/users_admin">USERS</a>
                          </li>
                          <li>
                            <a href="<?=base_url()?>main/admin_trans_all">TRANSACTIONS</a>
                          </li>
                          <li>
                            <a href="<?=base_url()?>main/user_all_email">GENERATE EMAIL</a>
                          </li>

                        </ul>
                      </li>
                    <?php }?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

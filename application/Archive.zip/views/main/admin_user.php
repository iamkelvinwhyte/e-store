<?php include 'inc/header.php'; ?>
    <body>
        <div class='loader'>
            <div class='spinner-grow text-primary' role='status'>
                <span class='sr-only'>Loading...</span>
            </div>
        </div>
        <div class="connect-container align-content-stretch d-flex flex-wrap">
            <div class="page-container">
              <?php include 'inc/top_nav.php'; ?>
              <?php include 'inc/navbar.php'; ?>

                <div class="page-content" ng-app="myTrade" ng-controller="TradeCtrl" ng-init="show_data()" ng-cloak>

                <?php if($this->session->userdata("active")==0){ ?>
                <div class="alert alert-danger">
                    <center><h3>Almost done...</h3><strong> We've sent an email to <u><?=$this->session->userdata("email")?></u>. Open it up to activate your account.</strong></center>
                </div>
              <?php }?>

                    <div class="page-info container">

                        <div class="row">
                            <div class="col">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#"><?=$this->config->item('site_name');?></a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Admin Users</li>
                                    </ol>
                                </nav>

                            </div>
                        </div>
                    </div>

                        <div class="col-lg-12">
                            <div class="card card-transactions">
                                <div class="card-body">
                                    <h5 class="card-title">Register Users<a href="#" class="card-title-helper blockui-transactions"><i class="material-icons">refresh</i></a></h5>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th scope="col">ID</th>
                                                    <th scope="col">First Name</th>
                                                    <th scope="col">Last Name</th>
                                                    <th scope="col">Email</th>
                                                    <th scope="col">Status</th>
                                                    <th scope="col">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody dir-paginate="x in getUser|orderBy:sortKey:reverse|filter:userSearch|itemsPerPage:20">
                                                <tr>
                                                    <td>{{x.personal_info_id}}</td>
                                                    <td>{{x.f_name}}</td>
                                                    <td>{{x.l_name}}</td>
                                                      <td>{{x.email}}</td>
                                                    <td><span class="badge badge-success" ng-show="x.active==1">active</span>
                                                      <span class="badge badge-warning" ng-show="x.active==0">not active</span>

                                                    </td>
                                                    <td>
                                                      <button type="submit" class="btn btn-danger btn-sm" ng-click="users_action(x.personal_info_id,1)">delete </button>
                                                      <button type="submit" class="btn btn-warning btn-sm"ng-click="users_action(x.personal_info_id,2)">block </button>
                                                    </td>
                                                </tr>

                                            </tbody>
                                        </table>
                                        <!--Pagination --->
                                        <dir-pagination-controls
                                        max-size="20"
                                        direction-links="true"
                                        boundary-links="true" >
                                      </dir-pagination-controls>
                                      <!--Pagination --->
                                    </div>
                                </div>
                            </div>
                        </div>





                </div>
                <div class="page-footer">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                              <span class="footer-text"><?=date("Y")?> © <?=$this->config->item('site_name');?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php include 'inc/footer.php'; ?>

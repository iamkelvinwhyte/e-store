<?php include 'inc/header.php'; ?>
    <body class="auth-page sign-in">

        <div class='loader'>
            <div class='spinner-grow text-primary' role='status'>
                <span class='sr-only'>Loading...</span>
            </div>
        </div>
        <div class="connect-container align-content-stretch d-flex flex-wrap">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="auth-form">
                            <div class="row">

                                <div class="col">
                                    <div class="logo-box"><a href="#" class="logo-text">RESET PASSWORD</a></div>
                                    <?=validation_errors('<div class="alert alert-danger">
                                    <center><strong>','</strong></center></div>'); ?>
                                    <?php
                                    if(isset($_SESSION['error'])){
                                      echo '<div class="alert alert-danger">
                                      <center><strong>'.$this->session->flashdata('error').'</strong></center></div>';
                                    }
                                    if(isset($_SESSION['success'])){
                                      echo '<div class="alert alert-success">
                                      <center><strong>'.$this->session->flashdata('success').'</strong></center></div>';
                                    }
                                    ?>
                                    <form method="post" action="<?=base_url()?>auth/password_account_change/<?=$this->uri->segment('3')?>">
                                      <div class="form-group">
                                          <input type="password"  name="password" class="form-control" id="exampleInputPassword1" placeholder="Password" required>
                                      </div>
                                      <div class="form-group">
                                          <input type="password" name="passconf" class="form-control" id="exampleInputPassword1" placeholder="Confim Password" required>
                                      </div>



                                        <button type="submit" class="btn btn-warning btn-block btn-submit">Continue</button>
                                        <div class="auth-options">

                                        <a href="<?=base_url()?>auth" class="forgot-link">Already have an account?</a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="auth-image"></div>
                    </div>
                </div>
            </div>
        </div>


<?php include 'inc/footer.php'; ?>

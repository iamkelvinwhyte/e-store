<div style="background-color:#F9F9F9">
<h1>Welcome to <span style="color:#FF8C00">Arcadia invest Referral </span></h1>

<p>
  You recently have a new refferal downliner on your account .
</p>
<p>
  Login to your  Arcadia wallet to view your new referral details .
</p>

<br>
If you have any questions please feel free to reach out to us using the information on our Contact Us page.
<br>
<i>Sincerely,
The Arcadia Team
</i>
</p>
</div>

<?php include 'inc/header.php'; ?>
    <body>
        <div class='loader'>
            <div class='spinner-grow text-primary' role='status'>
                <span class='sr-only'>Loading...</span>
            </div>
        </div>
        <div class="connect-container align-content-stretch d-flex flex-wrap">
            <div class="page-container">
              <?php include 'inc/top_nav.php'; ?>
              <?php include 'inc/navbar.php'; ?>

                <div class="page-content">

                <?php if($this->session->userdata("active")==0){ ?>
                <div class="alert alert-danger">
                    <center><h3>Almost done...</h3><strong> We've sent an email to <u><?=$this->session->userdata("email")?></u>. Open it up to activate your account.</strong></center>
                </div>
              <?php }?>

                    <div class="page-info container">

                        <div class="row">
                            <div class="col">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#"><?=$this->config->item('site_name');?></a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Make withdrawal</li>
                                    </ol>
                                </nav>

                            </div>
                        </div>
                    </div>
                        <?php include 'inc/bal.php'; ?>
                    <div class="row">

                      <div class="col-lg-3"></div>
                            <div class="col-lg-6" >
                                <div class="card"  >
                                  <div class="card-header">

                                        <center><h3  href="#"><center> Make withdrawal</h3></center>

                                  </div>
                                  <div class="card-body" >
                                    <?php
                                    if(isset($_SESSION['error'])){
                                      echo '<div class="alert alert-danger">
                                      <center><strong>'.$this->session->flashdata('error').'</strong></center></div>';
                                    }
                                    if(isset($_SESSION['success'])){
                                      echo '<div class="alert alert-success">
                                      <center><strong>'.$this->session->flashdata('success').'</strong></center></div>';
                                    }
                                    ?>
                                  <form method="post" action="<?=base_url()?>main/make_withdrawl">

                                                 <div class="form-group">
                                                     <label for="inputAddress">Amount</label>
                                                     <input type="number" class="form-control" id="inputAddress"  name="amount" required>
                                                 </div>

                                                 <div class="form-group">
                                                   <label for="exampleInputEmail1">Payment out  Method</label>
                                                   <select class="custom-select form-control" name="payment_type" required>
                                                        <option value="" selected>Select Payment Method</option>
                                                        <option value="1">Bitcon</option>
                                                        <option value="2">Ethereum</option>

                                                    </select>
                                                 </div>

                                                 <button type="submit" class="btn btn-warning btn-block ">continue</button>
                                             </form>

                                </div>
                                </div>
                            </div>
                              <div class="col-lg-3"></div>

                        </div>





                </div>
                <div class="page-footer">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                              <span class="footer-text"><?=date("Y")?> © <?=$this->config->item('site_name');?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php include 'inc/footer.php'; ?>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lb extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('Check_user');
        $this->load->model('Auth_model');
        $this->load->model('User_model');
        $this->load->model('Homepage_model');

        }

    //Buy Cal
public function profit_ph(){

$data2 = ['confirm_payement' =>1 ,  'aprove' =>1 ,'due >=' => date('Y-m-d'),];

$data=$this->Homepage_model->DisplayAll_('transaction',$data2,'in_transaction_id');


    $sum = 0;
    foreach($data as $datax){
    $amt= $datax["amount"];
    $bal= $datax["bal"];
    $rate= $datax["rate"];
    $duration= $datax["duration"];
    $ct= $datax["ct"];
    $ids=$datax["in_transaction_id"];
    $get_rate=$rate/100;
    $get_profit=$amt*$get_rate;
    $daily_credit=$get_profit/$duration;

    $total=$daily_credit +$bal;

$data2x = array(
    //   'due >' => date('Y-m-d'),
      'aprove' => 1,
      'confirm_payement' =>1,
     'duration > '=>$ct,
      'in_transaction_id'=>$ids,

      );
  $data = array(
    'bal' => $total,
    'ct' =>$ct+1 );


  $dataq = $this->Homepage_model->update_Data($data2x,$data,"transaction");
  if ( $dataq==1) {

  echo true;
  } else
  {
  echo false;
   }

  }

}


public function test(){
    echo "its working ";
}

}

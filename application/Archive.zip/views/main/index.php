<?php include 'inc/header.php'; ?>
    <body>
        <div class='loader'>
            <div class='spinner-grow text-primary' role='status'>
                <span class='sr-only'>Loading...</span>
            </div>
        </div>
        <div class="connect-container align-content-stretch d-flex flex-wrap" ng-app="myTrade" ng-controller="TradeCtrl" ng-init="show_data()" ng-cloak>
            <div class="page-container">
              <?php include 'inc/top_nav.php'; ?>
              <?php include 'inc/navbar.php'; ?>

                <div class="page-content">

                <?php if($this->session->userdata("active")==0){ ?>
                <div class="alert alert-danger">
                    <center><h3>Almost done...</h3><strong> We've sent an email to <u><?=$this->session->userdata("email")?></u>. Open it up to activate your account.</strong></center>
                </div>
              <?php }?>

                    <div class="page-info container" >
                        <div class="row">
                            <div class="col">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#"><?=$this->config->item('site_name');?></a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Overview </li>
                                    </ol>
                                </nav>
                                  <?php if($this->session->userdata("active")==1){ ?>
                                <div class="page-options">
                                    <a href="<?=base_url()?>main/plan" class="btn btn-warning">Investment Now</a>
                                </div>
                                  <?php }?>
                            </div>
                        </div>
                        <div style="pointer-events:none; height:62px; background-color: #FFFFFF; overflow:hidden; box-sizing: border-box; border: 1px solid #FFFFFF; border-radius: 4px; text-align: right; line-height:14px; block-size:62px; font-size: 12px; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #FFFFFF;padding:1px;padding: 0px; margin: 0px; width: 100%;"><iframe src="https://widget.coinlib.io/widget?type=horizontal_v2&theme=light&pref_coin_id=1505&invert_hover=" width="100%" height="36px" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;"></iframe></div>
                    </div>

                    <div class="main-wrapper container">
                        <?php include 'inc/bal.php'; ?>
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="card savings-card">
                                    <div class="card-body">
                                        <h5 class="card-title">Investments<span class="card-title-helper">30 Days</span></h5>
                                        <div class="savings-stats">
                                            <h5>$<?=number_format($this->Homepage_model->TotalInvest(),2)?></h5>
                                            <span>Total wallet balance</span>
                                        </div>
                                        <div id="sparkline-chart-1"></div>
                                    </div>
                                </div>
                                <div class="card top-products">
                                    <div class="card-body">
                                        <h5 class="card-title">Popular Products<span class="card-title-helper">Today</span></h5>
                                        <div class="top-products-list">
                                  <div style="width: 100%; height:220px; background-color: #FFFFFF; overflow:hidden; box-sizing: border-box; border: 1px solid #FFFFFF; border-radius: 4px; text-align: right; line-height:14px; block-size:220px; font-size: 12px; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #56667F;padding:1px;padding: 0px; margin: 0px;"><div style="height:200px; padding:0px; margin:0px; width: 100%;"><iframe src="https://widget.coinlib.io/widget?type=single_v2&theme=light&coin_id=859&pref_coin_id=1505" width="250" height="196px" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;line-height:14px;"></iframe></div></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-8">
                                <div class="card">

                                    <div class="card-body">
                                        <div style="height:560px; background-color: #FFFFFF; overflow:hidden; box-sizing: border-box; border: 1px solid #FFFFFF; border-radius: 4px; text-align: right; line-height:14px; font-size: 12px; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #FFFFFF;padding:1px;padding: 0px; margin: 0px; width: 100%;"><div style="height:540px; padding:0px; margin:0px; width: 100%;"><iframe src="https://widget.coinlib.io/widget?type=chart&theme=light&coin_id=859&pref_coin_id=1505" width="100%" height="536px" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;line-height:14px;"></iframe></div></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="alert alert-info no-m" role="alert">
                                        Data has been updated 35 minutes ago
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <div class="card card-transactions">
                                    <div class="card-body">
                                        <h5 class="card-title">Transactions<a href="#" class="card-title-helper blockui-transactions"><i class="material-icons">refresh</i></a></h5>
                                        <div class="table-responsive">
                                            <table class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">ID</th>
                                                        <th scope="col">Transactions</th>
                                                        <th scope="col">Amount</th>
                                                        <th scope="col">Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody ng-repeat="x in getTrans">
                                                    <tr>
                                                        <td>{{x.invoice}}</td>
                                                      <td>
                                                        <span class="badge badge-success" ng-show="x.trans_type==1">+invest</span>
                                                        <span class="badge badge-primary" ng-show="x.trans_type==2">+reinvest</span>
                                                        <span class="badge badge-danger" ng-show="x.trans_type==3">-withdrawl</span>
                                                      </td>
                                                        <td>{{x.amount | currency}}</td>
                                                        <td>
                                                          <span class="badge badge-success" ng-show="x.aprove==1">succesful</span>
                                                            <span class="badge badge-warning" ng-show="x.aprove==0">pending</span>
                                                        </td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="page-footer">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                              <span class="footer-text"><?=date("Y")?> © <?=$this->config->item('site_name');?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php include 'inc/footer.php'; ?>

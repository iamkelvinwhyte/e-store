
<?=include('include/header.php')?>

<?=include('include/nav-bar.php')?>
		<!-- begin #content -->
		<div id="content" class="content">
			<!-- begin breadcrumb -->
			<ol class="breadcrumb pull-right">
				<li class="breadcrumb-item"><a href="javascript:;">Home</a></li>
				<li class="breadcrumb-item"><a href="javascript:;">Dashboard</a></li>

			</ol>

			<!-- begin page-header -->
			<h1 class="page-header">Dashboard <small></small></h1>
			<!-- end page-header -->

			<!-- begin row -->
			<div class="row">
                <!-- begin col-3 -->

                </div>
			<!-- begin panel -->
			<div class="panel panel-inverse">
				<div class="panel-heading">
					<div class="panel-heading-btn">
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-redo"></i></a>
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger" data-click="panel-remove"><i class="fa fa-times"></i></a>
					</div>
					<h4 class="panel-title">Dashboard</h4>
				</div>
				<div class="panel-body" ng-app="myStock" ng-controller="StockCtrl" ng-init="show_data()">
                <div class="table-responsive">
						<table class="table table-bordered no-margin ">
						  <thead>
								<tr>
										<th scope="col">Type</th>
										<th scope="col"> Name</th>
										<th scope="col">Amount</th>
										<th scope="col"> Date</th>
										<th scope="col">Due Date</th>

											<th scope="col">Status</th>
										<th scope="col">Action</th>
								</tr>
						  </thead>
						  <tbody dir-paginate="x in myUserData|orderBy:sortKey:reverse|filter:userSearch|itemsPerPage:10">
								<tr>
									<td>
									<a href="<?=base_url()?>admin/transact_details/{{x.in_transaction_id}}">  <span  class="badge badge-success " ng-show="x.trans_type==1">+invest</span></a>
									<a href="<?=base_url()?>admin/transact_details/{{x.in_transaction_id}}">  <span class="badge badge-primary" ng-show="x.trans_type==2">+reinvest</span></a>
								<a href="<?=base_url()?>admin/transact_details/{{x.in_transaction_id}}"> <span class="badge badge-danger" ng-show="x.trans_type==3">-withdrawl</span></a>
									</td>
										<td>{{x.f_name}} {{x.l_name}}</td>
											<td>{{x.amount | currency}}</td>
												<td>{{x.date}}</td>
												<td>{{x.due}}</td>

										<td><span class="badge badge-success" ng-show="x.aprove==1">active</span>
											<span class="badge badge-warning" ng-show="x.aprove==0">not active</span>

										</td>
										<td>
											<button type="submit" class="btn btn-danger btn-sm" ng-click="transac_action(x.in_transaction_id,1,x.duration)" >delete </button>
											<button type="submit" class="btn btn-warning btn-sm"ng-click="transac_action(x.in_transaction_id,2,x.duration)" ng-hide="x.confirm_payement==1">approve </button>

										</td>
								</tr>

						  </tbody>
                        </table>
                         <!--Pagination -->
				<dir-pagination-controls
					max-size="10"
					direction-links="true"
					boundary-links="true" >
				</dir-pagination-controls>
				<!--Pagination -->
					</div>

				</div>
            </div>

			<!-- end panel -->
		</div>
		<!-- end #content -->


		<!-- begin scroll to top btn -->
		<a href="javascript:;" class="btn btn-icon btn-circle btn-success btn-scroll-to-top fade" data-click="scroll-top"><i class="fa fa-angle-up"></i></a>
		<!-- end scroll to top btn -->
	</div>
	<!-- end page container -->
    <script>

	var Stock = angular.module('myStock', ['angularUtils.directives.dirPagination']);
	////// STOCK QUERY DETAILS///////////
Stock.controller("StockCtrl", function($scope, $http) {
	 $scope.show_data = function() {
$http.get("<?=base_url()?>Admin/getDeposit/1")
            .then(function (response) {
               $scope.myUserData = response.data; //data call
            });
	 }
   //Upadte Database
    $scope.update_data = function(in_transaction_id,duration) {
       if (confirm("Are you sure you want to Confirm This Payment?")) {
            $http.post("<?=base_url()?>Admin/AdminUpdateTrans_T", {
                    'in_transaction_id': in_transaction_id,
                    'duration':duration
                })
                 .then(function (response) {
                    alert(response.data);
                    $scope.show_data();
                });
        } else {
            return false;
        }

    }
	//alert Database
    $scope.delete_data = function(in_transaction_id) {
        if (confirm("Are you sure you want to Delete Transaction?")) {
              $http.post("<?=base_url()?>Admin/Remove_transaction", {
				'in_transaction_id': in_transaction_id
                })
                .then(function (response) {
                    alert(response.data);
                    $scope.show_data();
                });
        } else {
            return false;
        }
    }

		$scope.transac_action = function(in_transaction_id,type,duration) {
		   if (confirm("Are you sure you want to perform this action?")) {
		        $http.post("<?=base_url()?>main/TransactionAction", {
		                'in_transaction_id': in_transaction_id,
		                  'type': type,
		                  'duration':duration
		            })
		             .then(function (response) {
		                  swal("Successful!", "You action has been completed!", "success");
		                $scope.show_data();
		            });
		    } else {
		        return false;
		    }

		}

});



	</script>
	<?=include('include/footer.php')?>

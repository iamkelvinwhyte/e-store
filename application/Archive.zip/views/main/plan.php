<?php include 'inc/header.php'; ?>
    <body>
        <div class='loader'>
            <div class='spinner-grow text-primary' role='status'>
                <span class='sr-only'>Loading...</span>
            </div>
        </div>
        <div class="connect-container align-content-stretch d-flex flex-wrap">
            <div class="page-container">
              <?php include 'inc/top_nav.php'; ?>
              <?php include 'inc/navbar.php'; ?>

                <div class="page-content" ng-app="myTrade" ng-controller="TradeCtrl" ng-init="show_data()" ng-cloak>

                <?php if($this->session->userdata("active")==0){ ?>
                <div class="alert alert-danger">
                    <center><h3>Almost done...</h3><strong> We've sent an email to <u><?=$this->session->userdata("email")?></u>. Open it up to activate your account.</strong></center>
                </div>
              <?php }?>

                    <div class="page-info container">
                        <div class="row">
                            <div class="col">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#"><?=$this->config->item('site_name');?></a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Plan</li>
                                    </ol>
                                </nav>

                            </div>
                        </div>
                    </div>
  <?php include 'inc/bal.php'; ?>
                    <div class="row">
                            <div class="col-lg-4" ng-repeat="x in getPlan">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title"><center>{{x.currency}}</center></h5>
                                        <h1 style="color:#000000"> <center>%{{x.percent}}</center></h1>
                                        <hr>
                                        <div id="tree1">
                                            <ul style="color:#000000; font-size: 15px;">
                                             <li>Days : {{x.days}}</li>
                                              <li>Minimum : {{x.min | currency}}</li>
                                              <li>Maximum : {{x.max | currency}}</li>
                                            </ul>
                                          </div>
                                            <?php if($this->session->userdata("active")==1){ ?>
                                          <a href="<?=base_url()?>main/invest_calculate/{{x.rate_id}}" type="button" class="btn  {{x.state}} btn-block text-white">Invest</a>
                                              <?php }?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>



                </div>
                <div class="page-footer">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <span class="footer-text"><?=date("Y")?> © <?=$this->config->item('site_name');?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php include 'inc/footer.php'; ?>

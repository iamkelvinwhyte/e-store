<!-- ================== BEGIN BASE JS ================== -->
<script src="<?= base_url()?>assets/admin/assets/plugins/jquery/jquery-3.2.1.min.js"></script>
	<script src="<?= base_url()?>assets/admin/assets/plugins/jquery-ui/jquery-ui.min.js"></script>
	<script src="<?= base_url()?>assets/admin/assets/plugins/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>
	<!--[if lt IE 9]>
		<script src="<?= base_url()?>assets/admin/assets/crossbrowserjs/html5shiv.js"></script>
		<script src="<?= base_url()?>assets/admin/assets/crossbrowserjs/respond.min.js"></script>
		<script src="<?= base_url()?>assets/admin/assets/crossbrowserjs/excanvas.min.js"></script>
	<![endif]-->
	<script src="<?= base_url()?>assets/admin/assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
	<script src="<?= base_url()?>assets/admin/assets/plugins/js-cookie/js.cookie.js"></script>
	<script src="<?= base_url()?>assets/admin/assets/js/theme/default.min.js"></script>
	<script src="<?= base_url()?>assets/admin/assets/js/apps.min.js"></script>
	<!-- ================== END BASE JS ================== -->

	<script>
		$(document).ready(function() {
			App.init();
		});
	</script>
</body>
</html>


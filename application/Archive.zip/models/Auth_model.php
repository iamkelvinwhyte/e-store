<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_model extends CI_Model {



    /*
     * Fetch user data
     */

public function Apikeyogin_($data){
$this->db->select('*');
$this->db->from('keys');
$this->db->where($data);
$this->db->limit(1);
$query = $this->db->get();
if ($query->num_rows() == 1) {
return $query->result();
} else {
return false;
}

}

public function Reg_($data){
$query=$this->db->insert('personal_info', $data);
return $query;

}

public function Reg_User($db,$data){
$query=$this->db->insert($db, $data);
return TRUE;

}

public function Reg_User_dupli($db,$data,$data2){
$this->db->select('*');
$this->db->from($db);
$this->db->where($data2);
$query = $this->db->get();
if ($query->num_rows() == 1) {
return false;
} else {
$query=$this->db->insert($db, $data);
return TRUE;
}
}

public function Login_($db,$email){
$this->db->select('*');
$this->db->from($db);
$this->db->where("(email = '$email' OR phone = '$email')");
$this->db->limit(1);
$query = $this->db->get();
if ($query->num_rows() == 1) {
return $query->result();
} else {
return false;
}
}

public function Login_2($db,$data){
$this->db->select('*');
$this->db->from($db);
$this->db->where($data);
$this->db->limit(1);
$query = $this->db->get();
if ($query->num_rows() == 1) {
return $query->result();
} else {
return false;
}
}

public function Login_mobile($db,$email){
$this->db->select('*');
$this->db->from($db);
$this->db->where("(email = '$email' OR phone = '$email')");
$this->db->where('status', 1);
$this->db->limit(1);
$query = $this->db->get();
if ($query->num_rows() == 1) {
return $query->result();
} else {
return false;
}


}

public function Login_3($db,$data){
$this->db->select('*');
$this->db->from($db);
$this->db->where($data);
$this->db->limit(1);
$query = $this->db->get();
if ($query->num_rows() == 1) {
return $query->result();
} else {
return false;
}


}

public function Login_Auto($data){
$this->db->select('*');
$this->db->from('personal_info');
$this->db->where($data);
$this->db->limit(1);
$query = $this->db->get();
if ($query->num_rows() == 1) {
return $query->result();
} else {
return false;
}


}

public function AdminLogin_($data){
	$this->db->select('*');
	$this->db->from('user');
	$this->db->where($data);
	$this->db->limit(1);
	$query = $this->db->get();
	if ($query->num_rows() == 1) {
	return $query->result();
	} else {
	return false;
	}


	}

public function SubLogin_($data){
$this->db->select('*');
$this->db->from('store_login');
$this->db->where($data);
$query = $this->db->get();
return $query->num_rows();

}

public function DisplayUser_(){
$query =$this->db->query('SELECT * FROM personal_info ');
return $query->result_array();

}


public function DisplayUser_Name($data){
$this->db->select('*');
$this->db->from('personal_info');
$this->db->where($data);
$query = $this->db->get();
$datax = $query->result_array();
 foreach ($datax  as $roww)
{

  return $roww['name'];

 }
}


public function DisplayUserByStore_($data){
$this->db->select('*');
$this->db->from('personal_info');
$this->db->where($data);
$query = $this->db->get();
return $query->result_array();

}



public function ApproveUser_($personal_info_id, $data){
$this->db->where('personal_info_id', $personal_info_id);
$this->db->update('personal_info', $data);
return TRUE;
}

public function UpdateUser_($query_array, $data){
$this->db->update('personal_info', $data,$query_array);
return TRUE;
}

public function UpdateUser_2($db,$query_array, $data){
$this->db->update($db, $data,$query_array);
return TRUE;
}
public function Passwd_($query_array, $data){
$this->db->update('personal_info', $data,$query_array);
return TRUE;
}

public function UpdateLog_($data){
$this->db->replace('login_session',$data);
return TRUE;
}


public function LoginCheck_($data){
$this->db->select('*');
$this->db->from('login_session');
$this->db->where($data);
//$this->db->limit(1);
$query = $this->db->get();
$vat= $query->num_rows();
return $vat;

}

public function AsignStore_($data,$dataA){
$this->db->select('*');
$this->db->from('store_login');
$this->db->where($data);
$this->db->limit(1);
$query = $this->db->get();
if ($query->num_rows() == 1) {
return FALSE;
} else {
$this->db->insert('store_login', $dataA);
return TRUE;
}


}
//Menu AsignStore

public function MenuAssgn_($data){
$this->db->select('*');
$this->db->from('in_user_menu');
$this->db->where($data);
$this->db->limit(1);
$query = $this->db->get();
if ($query->num_rows() == 1) {
return FALSE;
} else {
$this->db->insert('in_user_menu', $data);
return TRUE;
}
}

// Display OutletAssign
function  Display_Outlet($data){
$this->db->select("personal_info.name,in_store.store_name,store_login.date,store_login.store_login_id");
$this->db->from('store_login');
$this->db->where($data);
$this->db->join('in_store', 'in_store.store_sub_id=store_login.sub_store_vid');
$this->db->join('personal_info', 'store_login.personal_info_id=personal_info.personal_info_id');
$query=$this->db->get();
return $query->result_array();
}

//Remove OutLet User
function Del_outletUser_($id){
$this->db->where('store_login_id', $id);
$a=$this->db->delete('store_login');
if(isset($a)){return TRUE;}else{return FALSE;}

}


//Activationcode
public function activation_code($maxlength)
{
	$this->load->model('Homepage_model');
	$chary = array( "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",  );
$return_str = "";
for ( $x=0; $x<=$maxlength; $x++ )
{
	$return_str .= $chary[rand(0, count($chary)-1)];
	$return_str;
}

	$dd= array(
         'classID'=>$return_str,

             );
	$this->Homepage_model->insertData_('classid',$dd);
	$data=$this->Homepage_model->DisplayAl1_('classid',$dd,'class_id');

		foreach($data as $key){
			$id=$key['class_id'];
			$classD=$key['classID'];
		}
	return $id.$classD;

}


//Generrate Item Code
public function random_code($maxlength)
{
$bytes = random_bytes($maxlength);
return (bin2hex($bytes));

}



}

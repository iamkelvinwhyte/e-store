<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

  public function __construct() {
    parent::__construct();
    //$this->_is_logged_in();
    //$this->CheckUser();
    $this->load->model('Check_user');
    $this->Check_user-> _is_logged_inAdmin();
    $this->load->model('Auth_model');
    $this->load->model('User_model');
    $this->load->model('Homepage_model');

  }

  public function login()
  {
    $this->load->view('admin/index.php');
  }
  public function index()
  {
    $this->load->view('admin/index.php');
  }

  public function Dashboard()
  {
    $this->load->view('admin/home.php');
  }
  public function transac()
  {
    $this->load->view('admin/transaction.php');
  }
  public function userx()
  {
    $this->load->view('admin/users.php');
  }

  public function rate()
  {
    $this->load->view('admin/rate.php');
  }
  public function password()
  {
    $this->load->view('admin/password.php');
  }
  public function wallet()
  {
    $this->load->view('admin/wallet.php');
  }



    public function transac1()
	{
	$this->load->view('admin/trans_1.php');
    }
    public function transac2()
	{
	$this->load->view('admin/trans_2.php');
    }
    public function transac3()
	{
	$this->load->view('admin/trans_3.php');
    }


  public function edit_rate($id)
  {
    $data_query= array
    (
      'rate_id' => $id,
    );
    $data=$this->User_model-> Displayrate_IN($data_query);
    $datax["datax"]=$data;
    $this->load->view('admin/rate_edit.php',$datax);
  }
  public function wallet_edit()
  {
    $this->load->view('admin/edit_wallet.php');
  }


  public function transact_details($in_transaction_id="")
  {
    $action="transaction.plan=rate.rate_id";
    $action2="transaction.personal_info_id=personal_info.personal_info_id";
    $dataGet = $this->Homepage_model->Display2Join_("transaction","rate","personal_info",["in_transaction_id"=>$in_transaction_id],"in_transaction_id",$action,$action2,"left","left");
    $data["trans"]=$dataGet;
    $this->load->view('admin/transaction_prv.php',$data);
  }
  public function email_check_all()
  {
    $this->load->view('email_cof.php');
  }

  //Admin Display
  public function get_TranscAdmin(){

    $m=$this->User_model->AdminDisplayTran_AD();
    $this->output->set_output(json_encode($m));

  }

  //Approve Transaction////
  public function AdminUpdateTrans_T()
  {
    $data  = json_decode(file_get_contents("php://input"));
    $in_transaction_id= $data->in_transaction_id;
    $duration= $data->duration;
    //$itemD=json_encode($in_cate_id);

    $dd="+".$duration."days";
    $data = array(
      'aprove' => 1,
      'due'  => date('Y-m-d', strtotime($dd)),
      'confirm_payement'=>1
    );
    $data2 = array(
      'in_transaction_id' => $in_transaction_id
    );
    $dataq = $this->User_model->update_Trans($data2,$data);
    if ( $dataq==1) {
      echo 'Payment Confirmation Was Successfully...';
    } else
    {
      echo 'Failed';
    }
  }

  //Approve Transaction////
  public function AdminBanUser_()
  {
    $data  = json_decode(file_get_contents("php://input"));
    $personal_info_id= $data->personal_info_id;
    //$itemD=json_encode($in_cate_id);
    $data = array(
      'active' => 0
    );
    $query_array = array(
      'personal_info_id' => $personal_info_id
    );
    $dataq = $this->Auth_model->UpdateUser_($query_array, $data);
    if ( $dataq==1) {
      echo 'You Action Was Successfully...';
    } else
    {
      echo 'Failed';
    }
  }

  //Activate User////
  public function AdminActivUser_()
  {
    $data  = json_decode(file_get_contents("php://input"));
    $personal_info_id= $data->personal_info_id;
    //$itemD=json_encode($in_cate_id);
    $data = array(
      'active' => 1
    );
    $query_array = array(
      'personal_info_id' => $personal_info_id
    );
    $dataq = $this->Auth_model->UpdateUser_($query_array, $data);
    if ( $dataq==1) {
      echo 'You Action Was Successfully...';
    } else
    {
      echo 'Failed';
    }
  }

  //DeleteUser////
  public function AdminDeleteUser_()
  {
    $data  = json_decode(file_get_contents("php://input"));
    $personal_info_id= $data->personal_info_id;
    $dataq = $this->User_model->Del_user_($personal_info_id);
    if ( $dataq==1) {
      echo 'You Action Was Successfully...';
    } else
    {
      echo 'Failed';
    }
  }

  //DELETE Transaction////
  public function Remove_transaction()
  {
    $data  = json_decode(file_get_contents("php://input"));
    $in_transaction_id= $data->in_transaction_id;
    //$itemD=json_encode($in_cate_id);
    $dataq = $this->User_model->Del_Tans_($in_transaction_id);
    if ( $dataq==1) {
      echo 'Your Action Was Successfully...';
    } else
    {
      echo 'Failed';
    }
  }



  //Admin Display
  public function get_RateAdmin(){

    $m=$this->User_model->AdminDisplayrate_();
    $this->output->set_output(json_encode($m));

  }
  //Admin Display
  public function get_walletAdAdmin(){

    $m=$this->User_model->AdminDisplaycur_AD();
    $this->output->set_output(json_encode($m));

  }
  //Admin Display
  public function get_Admin_Info(){

    $m=$this->User_model->AdminDisplayINFO_AD();
    $this->output->set_output(json_encode($m));

  }


  //UPDATE rate
  public function UpdateRate(){

    $data = array
    (
      'amt' => $this->input->post('amt'),

    );
    $id = array
    (
      'rate_id' => $this->input->post('rate_id'),
    );
    $query=$this->User_model->update_Rate($id,$data);
    if( $query!= false){
      $this->session->set_flashdata('success', 'Update Was Successful');
      redirect('Admin/rate', 'refresh');
    }else{

      $this->session->set_flashdata('error', 'Update Was Not Successful  ');
      redirect('Admin/rate', 'refresh');
    }

  }


  //UPDATE Address
  public function UpdateWalletAd(){

    $data = array
    (
      'address' => $this->input->post('adr'),

    );
    $id = array
    (
      'currency_address_id' => $this->input->post('currency_address_id'),
    );
    $query=$this->User_model->update_WalletD($id,$data);
    if( $query!= false){
      $this->session->set_flashdata('success', 'Update Was Successful');
      redirect('Admin/wallet', 'refresh');
    }else{

      $this->session->set_flashdata('error', 'Update Was Not Successful  ');
      redirect('Admin/wallet', 'refresh');
    }

  }
  public function logout() {

    // Removing session data
    $sess_array = array(
      'personal_info_id',
      'email' ,
      'phone' ,
      'name' ,
    );
    $this->session->unset_userdata('logged_in', $sess_array);
    $this->session->sess_destroy();
    $this->session->set_flashdata('error', 'You Have Successfully Logout ');
    redirect('Admin', 'refresh');
  }


  //Password
  public function PasswdA() {
    $this->form_validation->set_rules('password', 'Password', 'required');
    $this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');
    // Validate Operation
    if ($this->form_validation->run() == FALSE) {
      $this->load->view('admin/password');
    }
    else {
      $data = array
      (
        'password' => $this->input->post('password')

      );

      $query_array = array
      (

        'user_id' => $this->session->userdata('user_id'),


      );
      $query=$this->User_model->UserPasAdmin_($query_array, $data);
      if($query==1){
        $this->session->sess_destroy();
        $this->session->set_flashdata('success','Your Password was Change Successfully Login !!   ');

        redirect("Admin/login", 'refresh' );
      }else{
        $this->session->set_flashdata('error','Unable to Change Password   ');
        redirect("password", 'refresh' );
      }

    }
  }

  public function getDeposit($aprove){

      $action="transaction.personal_info_id=personal_info.personal_info_id";
     $data_A = ["trans_type!="=>3,"confirm_payement"=>$aprove];

     $data = $this->Homepage_model->DisplayJoin_('transaction','personal_info',$data_A,'in_transaction_id',$action,'left');
     $this->output->set_output(json_encode($data));

}

public function getWithdraw($aprove){

    $action="transaction.personal_info_id=personal_info.personal_info_id";
   $data_A = ["trans_type"=>3,"confirm_payement"=>$aprove];

   $data = $this->Homepage_model->DisplayJoin_('transaction','personal_info',$data_A,'in_transaction_id',$action,'left');
   $this->output->set_output(json_encode($data));

}




}

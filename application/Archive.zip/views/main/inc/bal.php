<div class="row stats-row">
    <div class="col-lg-4 col-md-12">
        <div class="card card-transparent stats-card">
            <div class="card-body">
                <div class="stats-info">
                    <h5 class="card-title">$ <?=number_format($this->Homepage_model->walletBal(),2)?><span class="stats-change stats-change-success">+10%</span></h5>
                    <p class="stats-text">Total Balance</p>
                </div>
                <div class="stats-icon change-success">
                    <i class="material-icons">trending_up</i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-md-12">
        <div class="card card-transparent stats-card">
            <div class="card-body">
                <div class="stats-info">
                    <h5 class="card-title">$ <?=number_format($this->Homepage_model->ProfitBalOnly(),2)?><span class="stats-change stats-change-success">+16%</span></h5>
                    <p class="stats-text">Total profit  in current period</p>
                </div>
                <div class="stats-icon change-success">
                    <i class="material-icons">trending_up</i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-md-12">
        <div class="card card-transparent stats-card">
            <div class="card-body">
                <div class="stats-info">
                    <h5 class="card-title">$ <?=number_format($this->Homepage_model->ReferralBal(),2)?><span class="stats-change stats-change-success">+12%</span></h5>
                    <p class="stats-text">Total referral</p>
                </div>
                <div class="stats-icon change-success">
                    <i class="material-icons">trending_up</i>
                </div>
            </div>
        </div>
    </div>
</div>

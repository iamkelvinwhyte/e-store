
<?=include('include/header.php')?>

<?=include('include/nav-bar.php')?>
		<!-- begin #content -->
		<div id="content" class="content">
			<!-- begin breadcrumb -->
			<ol class="breadcrumb pull-right">
				<li class="breadcrumb-item"><a href="javascript:;">Home</a></li>
				<li class="breadcrumb-item"><a href="javascript:;">Dashboard</a></li>

			</ol>

			<!-- begin page-header -->
			<h1 class="page-header">Dashboard <small></small></h1>
			<!-- end page-header -->

			<!-- begin row -->
			<div class="row">
                <!-- begin col-3 -->

                </div>
			<!-- begin panel -->
			<div class="panel panel-inverse">
				<div class="panel-heading">
					<div class="panel-heading-btn">
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-redo"></i></a>
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger" data-click="panel-remove"><i class="fa fa-times"></i></a>
					</div>
					<h4 class="panel-title">Dashboard</h4>
				</div>
				<div class="panel-body" ng-app="myStock" ng-controller="StockCtrl" ng-init="show_data()">
                <div class="table-responsive">
						<table class="table table-bordered no-margin ">
						  <thead>
							<tr>

														<th scope="col">ID</th>
														<th scope="col">First Name</th>
														<th scope="col">Last Name</th>
														<th scope="col">Email</th>
														<th scope="col">Status</th>
														  <th><span style="">date</span></th>
														<th scope="col">Action</th>



							</tr>
						  </thead>
						  <tbody dir-paginate="x in myUserData|orderBy:sortKey:reverse|filter:userSearch|itemsPerPage:10">
							<tr>

								<td>		<a href="<?=base_url()?>auth/AuthLogin/{{x.personal_info_id}}" traget="_">  <span  class="badge badge-success ">{{x.personal_info_id}}</span></a></td>
								<td>{{x.f_name}}</td>
								<td>{{x.l_name}}</td>
									<td>{{x.email}}</td>
								<td><span class="badge badge-success" ng-show="x.active==1">active</span>
									<span class="badge badge-warning" ng-show="x.active==0">not active</span>

								</td>

                              <td>
								<time class="timeago" >{{x.reg_date}}</time>
							  </td>

                              <td><span class="btn btn-xs btn-warning"  ng-hide="{{x.active==0}}" ng-click="update_data(x.personal_info_id)">Ban User</span>
                              <span class="btn btn-xs btn-success"  ng-hide="{{x.active==1}}" ng-click="update_dataA(x.personal_info_id)">Activate</span>
                              <span class="btn btn-xs btn-danger" ng-click="delete_data(x.personal_info_id)">Delete</span>
                            </td>
							</tr>

						  </tbody>
                        </table>
                        <!--Pagination -->
				<dir-pagination-controls
					max-size="10"
					direction-links="true"
					boundary-links="true" >
				</dir-pagination-controls>
				<!--Pagination -->
					</div>

				</div>
            </div>

			<!-- end panel -->
		</div>
		<!-- end #content -->


		<!-- begin scroll to top btn -->
		<a href="javascript:;" class="btn btn-icon btn-circle btn-success btn-scroll-to-top fade" data-click="scroll-top"><i class="fa fa-angle-up"></i></a>
		<!-- end scroll to top btn -->
	</div>
	<!-- end page container -->
    <script>

	var Stock = angular.module('myStock', ['angularUtils.directives.dirPagination']);
	////// STOCK QUERY DETAILS///////////
Stock.controller("StockCtrl", function($scope, $http) {
	 $scope.show_data = function() {
$http.get("<?=base_url()?>Admin/get_Admin_Info")
            .then(function (response) {
               $scope.myUserData = response.data; //data call
            });
	 }
   //Upadte Database
    $scope.update_data = function(personal_info_id) {
       if (confirm("Are you sure you want to Ban this user?")) {
            $http.post("<?=base_url()?>Admin/AdminBanUser_", {
                    'personal_info_id': personal_info_id
                })
                 .then(function (response) {
                    alert(response.data);
                    $scope.show_data();
                });
        } else {
            return false;
        }

    }
    //Upadte Database
    $scope.update_dataA = function(personal_info_id) {
       if (confirm("Are you sure you want to Activate this user?")) {
            $http.post("<?=base_url()?>Admin/AdminActivUser_", {
                    'personal_info_id': personal_info_id
                })
                 .then(function (response) {
                    alert(response.data);
                    $scope.show_data();
                });
        } else {
            return false;
        }

    }
	//alert Database
    $scope.delete_data = function(in_transaction_id) {
        if (confirm("Are you sure you want to Delete This User? No UNDO")) {
              $http.post("<?=base_url()?>Admin/AdminDeleteUser_", {
				'in_transaction_id': in_transaction_id
                })
                .then(function (response) {
                    alert(response.data);
                    $scope.show_data();
                });
        } else {
            return false;
        }
    }

});

	</script>
	<?=include('include/footer.php')?>

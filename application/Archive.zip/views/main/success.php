<?php include 'inc/header.php'; ?>
    <body>
        <div class='loader'>
            <div class='spinner-grow text-primary' role='status'>
                <span class='sr-only'>Loading...</span>
            </div>
        </div>
        <div class="connect-container align-content-stretch d-flex flex-wrap">
            <div class="page-container">
              <?php include 'inc/top_nav.php'; ?>
              <?php include 'inc/navbar.php'; ?>

                <div class="page-content" ng-app="myTrade" ng-controller="TradeCtrl" ng-init="show_data()" ng-cloak>

                <?php if($this->session->userdata("active")==0){ ?>
                <div class="alert alert-danger">
                    <center><h3>Almost done...</h3><strong> We've sent an email to <u><?=$this->session->userdata("email")?></u>. Open it up to activate your account.</strong></center>
                </div>
              <?php }?>

                    <div class="page-info container">
                        <div class="row">
                            <div class="col">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#"><?=$this->config->item('site_name');?></a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Plan Complete</li>
                                    </ol>
                                </nav>

                            </div>
                        </div>
                    </div>

                    <div class="row">
                      <div class="col-lg-4"></div>
                            <div class="col-lg-5" >
                                <div class="card"  >
                                  <div class="card-header " ng-init="trans_type=<?=$this->session->userdata("trans_type")?>">

                            <center><h3 class="" href="#" ng-show="trans_type==1"><center> You are almost done</h3></center>
                              <center><h3 class="te" href="#" ng-show="trans_type==2">
                                <img src="<?=base_url()?>assets/images/success.png" width="220px" height="220px">
                                <center> Thank You ,Your Investment has been confirmed</h3></center>

                                  </div>
                                  <div ng-show="trans_type==1" class="card-body" ng-init="amount=<?=$this->session->userdata("amount")?>">
                                  <center>
                                      <?php if($this->session->userdata("payment_type")==1){ ?>
                                     <img src="<?=base_url()?>assets/images/done.png" width="200px" height="150px">
                                   <?php }else{?>
                                     <img src="<?=base_url()?>assets/images/done2.png" width="200px" height="200px">
                                      <?php }?>
                                     <center><br>
                                <span> Complete your investments by transfering <h2>{{amount | currency}}</h2> to the
                                  <?php if($this->session->userdata("payment_type")==1){ ?>
                                 <strong style="color:#000000">BITCOIN</strong>
                               <?php }else{?>
                                <strong style="color:#000000"> ETHEREUM</strong>
                                  <?php }?>

                                  address below  </span><br>
                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <button class="input-group-text" id="inputGroupPrepend"><i class="material-icons-outlined" ng-click="myCopy()">copy</i></button>
                                                    </div>
                                                      <?php if($this->session->userdata("payment_type")==1){ ?>
                                                    <input type="text" class="form-control" id="wallet"  placeholder="<?=$this->config->item('wallet_address');?>" value="<?=$this->config->item('wallet_address');?>" aria-describedby="inputGroupPrepend" required>
                                                     <?php }else{?>

                                                       <input type="text" class="form-control" id="wallet"  placeholder="<?=$this->config->item('wallet_address_eth');?>" value="<?=$this->config->item('wallet_address_eth');?>" aria-describedby="inputGroupPrepend" required>

                                                         <?php }?>

                                                </div>
                                                <br>

                                                <div class="card-body">
                                        <h5 class="card-title">Upload Payment</h5>
                                        <p>Kindly upload proof of payment . </p>
                                        <form>
                                            <div class="form-group">
                                                
                                                <input  type="file"  accept="image/*"  id="file" class="form-control" >
                                                <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                                            </div>

                                            <button  class="btn btn-warning" ng-click="uploadPayment()" ng-hide="loading">Make Upload</button>
                                            <button  class="btn btn-warning" ng-show="loading">Loading...</button>
                                        </form>
                                    </div>

                                </div>
                                </div>
                            </div>
                              <div class="col-lg-4"></div>

                        </div>
                    </div>
                </div>



                </div>
                <div class="page-footer">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <span class="footer-text"><?=date("Y")?> © <?=$this->config->item('site_name');?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php include 'inc/footer.php'; ?>

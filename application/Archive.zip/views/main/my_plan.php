<?php include 'inc/header.php'; ?>
    <body>
        <div class='loader'>
            <div class='spinner-grow text-primary' role='status'>
                <span class='sr-only'>Loading...</span>
            </div>
        </div>
        <div class="connect-container align-content-stretch d-flex flex-wrap">
            <div class="page-container">
              <?php include 'inc/top_nav.php'; ?>
              <?php include 'inc/navbar.php'; ?>

                <div class="page-content" ng-app="myTrade" ng-controller="TradeCtrl" ng-init="show_data()" ng-cloak>

                <?php if($this->session->userdata("active")==0){ ?>
                <div class="alert alert-danger">
                    <center><h3>Almost done...</h3><strong> We've sent an email to <u><?=$this->session->userdata("email")?></u>. Open it up to activate your account.</strong></center>
                </div>
              <?php }?>

                    <div class="page-info container">
                        <div class="row">
                            <div class="col">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#"><?=$this->config->item('site_name');?></a></li>
                                        <li class="breadcrumb-item active" aria-current="page">My Plan</li>
                                    </ol>
                                </nav>

                            </div>
                        </div>
                    </div>
  <?php include 'inc/bal.php'; ?>
                    <div class="row">

                            <div class="col-lg-4
                            " ng-repeat="x in getMyPlan">
                                <div class="card">
                                  <div class="card-header {{x.state}}">

                                        <center><h3 class="text-white" href="#"><center>{{x.currency}} </h3></center>

                                  </div>

                                    <div class="card-body" >
                                      <div class="form-group" >

                                        <hr>
                                        <h4 style="color:#000000"><center>Profit Return</center> </h4>

                                        <table class="table table-striped">

                                            <tbody>
                                              <tr>
                                                <th scope="row">Precentage</th>
                                                <td>%{{x.rate}}</td>
                                              </tr>
                                              <tr>
                                                <th scope="row">Redemption</th>
                                                <td>{{x.duration}} days</td>

                                              </tr>
                                              <tr>
                                                <th scope="row">Profit</th>
                                                <td>  <h3 style="font-size:20px"> {{(x.rate/100)* x.amount | currency}} </h3></td>

                                              </tr>
                                              <tr>
                                                <th scope="row">Date</th>
                                                <td>   {{x.date}}</td>

                                              </tr>
                                            </tbody>
                                    </table>

                                      </div>
                                    </div>

                                </div>
                            </div>


                        </div>
                    </div>
                </div>



                </div>
                <div class="page-footer">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <span class="footer-text"><?=date("Y")?> © <?=$this->config->item('site_name');?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php include 'inc/footer.php'; ?>

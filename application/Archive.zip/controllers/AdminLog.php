<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AdminLog extends CI_Controller {
   
public function __construct() {
parent::__construct();
//$this->_is_logged_in();
//$this->CheckUser();

$this->load->model('Auth_model');
$this->load->model('User_model');

}
public function test()
	{

$ptn = "/^0/";  // Regex
$str = "0807063047170"; //Your input, perhaps $_POST['textbox'] or whatever
$rpltxt = "+234";  // Replacement string
echo preg_replace($ptn, $rpltxt, $str);

    }
	
    public function login()
	{
	$this->load->view('admin/index.php');
    }
public function index()
	{
    $this->load->view('admin/index.php');
	}
	





}




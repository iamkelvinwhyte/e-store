<?php include 'inc/header.php'; ?>
    <body>
        <div class='loader'>
            <div class='spinner-grow text-primary' role='status'>
                <span class='sr-only'>Loading...</span>
            </div>
        </div>
        <div class="connect-container align-content-stretch d-flex flex-wrap">
            <div class="page-container">
              <?php include 'inc/top_nav.php'; ?>
              <?php include 'inc/navbar.php'; ?>

                <div class="page-content" ng-app="myTrade" ng-controller="TradeCtrl" ng-init="show_data()" ng-cloak>

                <?php if($this->session->userdata("active")==0){ ?>
                <div class="alert alert-danger">
                    <center><h3>Almost done...</h3><strong> We've sent an email to <u><?=$this->session->userdata("email")?></u>. Open it up to activate your account.</strong></center>
                </div>
              <?php }?>

                    <div class="page-info container">
                        <div class="row">
                            <div class="col">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#"><?=$this->config->item('site_name');?></a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Plan Package</li>
                                    </ol>
                                </nav>

                            </div>
                        </div>
                    </div>

                    <div class="row">

                      <div class="col-lg-4"></div>
                            <div class="col-lg-4" ng-init="max = <?=$package->max?>">
                              <?php
                              if(isset($_SESSION['error'])){
                                echo '<div class="alert alert-danger">
                                <center><strong>'.$this->session->flashdata('error').'</strong></center></div>';
                              }
                              if(isset($_SESSION['success'])){
                                echo '<div class="alert alert-success">
                                <center><strong>'.$this->session->flashdata('success').'</strong></center></div>';
                              }
                              ?>
                                <div class="card"  ng-init="min = <?=$package->min?>">
                                  <div class="card-header <?=$package->state?>">

                                        <center><h3 class="text-white" href="#"><center> <?=$package->currency?></h3></center>

                                  </div>
                                    <form method="post" action="<?=base_url()?>main/confirm_trade">

                                    <div class="card-body" ng-init="days = <?=$package->days?>">
                                      <div class="form-group" ng-init="percent = <?=$package->percent?>">
                                        <label for="exampleInputEmail1">Payment Method</label>
                                        <select class="custom-select form-control" name="payment_type" required>
                                             <option value="" selected>Select Payment Method</option>
                                             <option value="1">Bitcon</option>
                                             <option value="2">Ethereum</option>

                                         </select>

                                        <label for="exampleInputEmail1">Enter Investment Amount</label>
                                        <input type="number" class="form-control" ng-model="amount" name="amount"  placeholder="Enter amount" ng-init="amount=0">
                                          <input type="hidden" name="percent" value="<?=$package->percent?>">
                                            <input type="hidden" name="days" value="<?=$package->days?>">
                                              <input type="hidden" name="rate_id" value="<?=$package->rate_id?>">

                                            <small  style="color:red" class="form-text text-muted">Minimum Value:{{min|currency}}  and  Maximum Value: {{max|currency}} </small>
                                        <hr>
                                        <h4 style="color:#000000"><center>Profit Return</center> </h4>

                                        <table class="table table-striped">

                                            <tbody>
                                              <tr>
                                                <th scope="row">Precentage</th>
                                                <td>%<?=$package->percent?></td>

                                              </tr>
                                              <tr>
                                                <th scope="row">Redemption</th>
                                                <td><?=$package->days?> days</td>

                                              </tr>
                                              <tr>
                                                <th scope="row">Profit</th>
                                                <td>  <h3 style="font-size:20px"> {{(percent/100)*amount | currency}} </h3></td>

                                              </tr>
                                            </tbody>
                                    </table>
                                    <div class="form-group">
                                                <div class="custom-control custom-checkbox">
                                                    <input class="custom-control-input" type="checkbox" id="gridCheck" name="pay_type">
                                                    <label class="custom-control-label" for="gridCheck">
                                                        <span style="color:#000000">Invest from wallet balance : $<?=number_format($this->Homepage_model->walletBal(),2)?> </span>
                                                    </label>
                                                </div>
                                            </div>
                                            <br>
<button  type="submit" class="btn  <?=$package->state?> btn-block text-white" ng-hide="amount < min  || amount > max || !amount">Continue</button>

                                      </div>
                                    </div>
                                  </form>
                                </div>
                            </div>
                              <div class="col-lg-4"></div>

                        </div>
                    </div>
                </div>



                </div>
                <div class="page-footer">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <span class="footer-text"><?=date("Y")?> © <?=$this->config->item('site_name');?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php include 'inc/footer.php'; ?>

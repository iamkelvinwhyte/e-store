<?php include 'inc/header.php'; ?>

<?php
foreach ($trans as $key ) {
  // code...
}
 ?>
    <body>
        <div class='loader'>
            <div class='spinner-grow text-primary' role='status'>
                <span class='sr-only'>Loading...</span>
            </div>
        </div>
        <div class="connect-container align-content-stretch d-flex flex-wrap">
            <div class="page-container">
              <?php include 'inc/top_nav.php'; ?>
              <?php include 'inc/navbar.php'; ?>

                <div class="page-content" ng-app="myTrade" ng-controller="TradeCtrl" ng-init="show_data()" ng-cloak>

                <?php if($this->session->userdata("active")==0){ ?>
                <div class="alert alert-danger">
                    <center><h3>Almost done...</h3><strong> We've sent an email to <u><?=$this->session->userdata("email")?></u>. Open it up to activate your account.</strong></center>
                </div>
              <?php }?>

                    <div class="page-info container">
                        <div class="row">
                            <div class="col">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#"><?=$this->config->item('site_name');?></a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Transaction Details </li>
                                    </ol>
                                </nav>

                            </div>
                        </div>
                    </div>

                    <div class="row" >
                      <div class="col-lg-4"></div>
                            <div class="col-lg-5" >
                                <div class="card"  >
                                  <div class="card-header bg-success" ng-init="trans_type=<?=$this->session->userdata("trans_type")?>">

                            <center><h3 class="text-white" href="#"><center> Transaction Details</h3></center>


                                  </div>
                                  <div  class="card-body" ng-init="amount=<?=$this->session->userdata("amount")?>">
                                    <table class="table table-striped">

                                        <tbody>
                                          <tr>
                                            <th scope="row">Full Name</th>
                                            <td><?=$key["f_name"]?> <?=$key["l_name"]?> </td>
                                          </tr>
                                          <tr>
                                            <th scope="row">Btc Address</th>
                                            <td><?=$key["btc_address"]?> </td>

                                          </tr>
                                          <tr>
                                            <th scope="row">Amount</th>
                                              <td>$<?=number_format($key["amount"],2)?> </td>

                                          </tr>
                                          <tr>
                                            <th scope="row">Date</th>
                                            <td><?=$key["date"]?> </td>

                                          </tr>

                                          <tr ng-init="trans_type =<?=$key["trans_type"]?>">
                                            <th scope="row">Type</th>
                                            <td>
                                            <span  class="badge badge-success " ng-show="trans_type==1">+invest</span>
                                             <span class="badge badge-primary" ng-show="trans_type==2">+reinvest</span>
                                         <span class="badge badge-danger" ng-show="trans_type==3">-withdrawl</span>
                                            </td>

                                          </tr >

                                          <tr ng-init="aprove =<?=$key["aprove"]?>">
                                            <th scope="row">Status</th>
                                            <td><span class="badge badge-success" ng-show="aprove==1">active</span>
                                              <span class="badge badge-warning" ng-show="aprove==0">not active</span>

                                            </td>

                                          </tr>

                                        </tbody>
                                </table>
                              <?php if ($key["pay_file"]): ?>
                                <img src="<?=base_url()?>uploads/<?=$key["pay_file"]?>" width="100%" height="400px">
                              <?php endif; ?>

                                </div>
                                </div>
                            </div>
                              <div class="col-lg-4"></div>

                        </div>
                    </div>
                </div>



                </div>
                <div class="page-footer">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <span class="footer-text"><?=date("Y")?> © <?=$this->config->item('site_name');?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php include 'inc/footer.php'; ?>

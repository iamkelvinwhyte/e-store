
				<!-- begin sidebar nav -->
				<ul class="nav">
					
					<li class="has-sub">
						<a href="<?=base_url()?>Admin/Dashboard">
					        <b class="caret"></b>
						    <i class=" fa fa-hdd"></i>
						    <span>Dashboard </span> 
						</a>
						
					</li>
					
				
						<li class="has-sub">
					    <a href="javascript:;">
					        <b class="caret"></b>
					        <i class="fa fa-list-ol"></i>
					        <span>Transaction</span>
					    </a>
						<ul class="sub-menu">
						
							<li><a href="<?=base_url()?>Admin/transac">Confirmed deposit </a></li>
							<li><a href="<?=base_url()?>Admin/transac1">Unconfirmed deposit</a></li>
								<li><a href="<?=base_url()?>Admin/transac2">Confirmed withdrawal</a></li>
									<li><a href="<?=base_url()?>Admin/transac3">Unconfirmed withdrawal</a></li>
						   
						</ul>
					</li>
					
					
					<li class="has-sub">
						<a href="<?=base_url()?>Admin/userx">
					        <b class="caret"></b>
						    <i class="fa fa-users"></i>
						    <span>Users</span> 
						</a>
						
					</li>
					<li class="has-sub">
					    <a href="javascript:;">
					        <b class="caret"></b>
					        <i class="fa fa-list-ol"></i>
					        <span>Setup</span>
					    </a>
						<ul class="sub-menu">
						
							<li><a href="<?=base_url()?>Admin/wallet">Set Trade & Bot</a></li>
							<li><a href="<?=base_url()?>Admin/password">Change Password</a></li>
						   
						</ul>
					</li>
					
					<li class="has-sub">
					    <a href="<?=base_url()?>Admin/logout">
					        <b class="caret"></b>
					        <i class="fa fa-logout"></i>
					        <span>Logout</span>
					    </a>
						
					</li>
					<li><a href="javascript:;" class="sidebar-minify-btn" data-click="sidebar-minify"><i class="fa fa-angle-double-left"></i></a></li>
			        <!-- end sidebar minify button -->
				</ul>
				<!-- end sidebar nav -->
			</div>
			<!-- end sidebar scrollbar -->
		</div>
		<div class="sidebar-bg"></div>
		<!-- end #sidebar -->